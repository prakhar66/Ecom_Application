//Automatically generated file for implementing asynchronous callback functions.
//You can modify the automatically generated callback implementations or add new ones.
//Asynchronous callback functions can be registered using web_reg_async_attributes steps.
int LongPoll_0_RequestCB()
{
	//Enter your implementation for RequestCB() here.

	//Call web_util_set_request_url() here to modify request URL:
	//web_util_set_request_url("<request url>");

	//Call web_util_set_request_body() here to modify request body:
	//TODO - Use snapshot view to see examples of request bodies sent.
	//web_util_set_request_body("<request body>");

	return WEB_ASYNC_CB_RC_OK;
}

int LongPoll_0_ResponseCB(
	const char *	aResponseHeadersStr,
	int				aResponseHeadersLen,
	const char *	aResponseBodyStr,
	int				aResponseBodyLen,
	int				aHttpStatusCode)
{
	//Enter your implementation for ResponseCB() here.

	//TODO - To make the script wait for a specific response, use web_sync in the relevant Action file.
	//See the Modifying Callbacks section in the VuGen user guide for more details.

	return WEB_ASYNC_CB_RC_OK;
}

int LongPoll_1_RequestCB()
{
	//Enter your implementation for RequestCB() here.

	//Call web_util_set_request_url() here to modify request URL:
	//web_util_set_request_url("<request url>");

	//Call web_util_set_request_body() here to modify request body:
	//TODO - Use snapshot view to see examples of request bodies sent.
	//web_util_set_request_body("<request body>");

	return WEB_ASYNC_CB_RC_OK;
}

int LongPoll_1_ResponseCB(
	const char *	aResponseHeadersStr,
	int				aResponseHeadersLen,
	const char *	aResponseBodyStr,
	int				aResponseBodyLen,
	int				aHttpStatusCode)
{
	//Enter your implementation for ResponseCB() here.

	//TODO - To make the script wait for a specific response, use web_sync in the relevant Action file.
	//See the Modifying Callbacks section in the VuGen user guide for more details.

	return WEB_ASYNC_CB_RC_OK;
}

