# 1 "d:\\etp\\scripts\\etp_normalusercreation\\\\combined_ETP_NormalUserCreation.c"
# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


# 1075 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_search_row(PVCI pvci, char * columnNames, char * messages, char * delimiter, char * **outcolumns, char * **outvalues);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);
VTCERR   vtc_update_all_message_ifequals(PVCI pvci, char * columnNames, char * message, char * ifmessage, char * delimiter, unsigned short *outRc);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_search_row(char * columnNames, char * messages, char * delimiter);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);
VTCERR   lrvtc_update_all_message_ifequals(char * columnNames, char * message, char * ifmessage, char * delimiter);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "d:\\etp\\scripts\\etp_normalusercreation\\\\combined_ETP_NormalUserCreation.c" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_search_row(PVCI2 pvci, char *columnNames, char *messages, char *delimiter, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_search_row(char *columnNames, char *messages, char *delimiter);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "d:\\etp\\scripts\\etp_normalusercreation\\\\combined_ETP_NormalUserCreation.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "lrw_custom_body.h" 1
 




# 8 "globals.h" 2

# 1 "AsyncCallbacks.c" 1
 
 
 
int LongPoll_0_RequestCB()
{
	 

	 
	 

	 
	 
	 

	return WEB_ASYNC_CB_RC_OK;
}

int LongPoll_0_ResponseCB(
	const char *	aResponseHeadersStr,
	int				aResponseHeadersLen,
	const char *	aResponseBodyStr,
	int				aResponseBodyLen,
	int				aHttpStatusCode)
{
	 

	 
	 

	return WEB_ASYNC_CB_RC_OK;
}

int LongPoll_1_RequestCB()
{
	 

	 
	 

	 
	 
	 

	return WEB_ASYNC_CB_RC_OK;
}

int LongPoll_1_ResponseCB(
	const char *	aResponseHeadersStr,
	int				aResponseHeadersLen,
	const char *	aResponseBodyStr,
	int				aResponseBodyLen,
	int				aHttpStatusCode)
{
	 

	 
	 

	return WEB_ASYNC_CB_RC_OK;
}

# 9 "globals.h" 2




 
 




# 3 "d:\\etp\\scripts\\etp_normalusercreation\\\\combined_ETP_NormalUserCreation.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 4 "d:\\etp\\scripts\\etp_normalusercreation\\\\combined_ETP_NormalUserCreation.c" 2

# 1 "Action.c" 1
Action()
{

	lr_start_transaction("ETP_NormalUserCreation_01_Launch");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_max_html_param_len("52056");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/UserLogin.aspx*",
		"LAST");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"SaveCount=LaunchCount",
		"Text=Division",
		"LAST");

	web_url("UserLogin.aspx",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t105.inf", 
		"Mode=HTML", 
		"LAST");

	web_convert_param("CorrelationParameter_URL2",
		"SourceString={CorrelationParameter}",
		"SourceEncoding=HTML",
		"TargetEncoding=URL",
		"LAST");

 

if (atoi(lr_eval_string("{LaunchCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_01_Launch",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_01_Launch",1);
        return(0);
         }

	lr_think_time(2);
	
	lr_start_transaction("ETP_NormalUserCreation_02_LoginDetails");

	web_add_auto_header("Origin", 
		"http://172.24.1.129");

	

	web_custom_request("UserLogin.aspx_2",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Snapshot=t106.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_URL2}&__VIEWSTATEGENERATOR=286ECC0B&__VIEWSTATEENCRYPTED=&txtUserName%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3BAdmin%26quot%3B%7D&txtUserName=Admin&txtPassword%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtPassword=&cmbDivision%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbDivision_VI=&cmbDivision=Division&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C0%3B%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbFacility_VI=&cmbFacility=Operating%20Unit&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCa"
		"llback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageWarningMsgCubeState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucVersionInfoState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucVersionInfo%24ASPxPanel1%24aspxVersionMemo=Product%20version%3A%20V5.5%20R10%0A%0ARelease%20Date%3A%2031-10-2018%0A%0ABuild%20No%3A%201.0%0A%0ABuild%20Date%3A%2031-10-2018&pucChangePasswordState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucPasswordChangeState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A"
		"-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionCheckState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_209%2C1_217%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_216%2C1_198&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_17%2C1_14%2C1_16%2C1_13%2CImages%2FIcons%2FETP_icon.ico%2CStyles%2FUserLogin.css%2CStyles%2FMaster.css%2CStyles%2FCommon.css%2CFont%2Ffonts.css%2CStyles%2FBusinessRule.css%2CStyles%2FLogin_style.css%2CStyles%2FloadingPanel.css&__CALLBACKID=cmbDivision&__CALLBACKPARAM=c0%3ALECC%7C0%3B%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");


	web_custom_request("UserLogin.aspx_3",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Snapshot=t107.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_URL2}&__VIEWSTATEGENERATOR=286ECC0B&__VIEWSTATEENCRYPTED=&txtUserName%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3BAdmin%26quot%3B%7D&txtUserName=Admin&txtPassword%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3Betp%40123%26quot%3B%7D&txtPassword=etp%40123&cmbDivision%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3BIndia%20Retail(888)%26quot%3B%7D&cmbDivision_VI=888&cmbDivision=India%20Retail(888)&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A554%3A314%3A1%3A289%3A28%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C0%3B%3B%26quot%3B%7D&cmbDivision%24DDD%24L=888&cmbFacility%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbFacility_VI=&cmbFacility=Operating%20Unit&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%"
		"7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B888%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageWarningMsgCubeState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucVersionInfoState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucVersionInfo%24ASPxPanel1%24aspxVersionMemo=Product%20version%3A%20V5.5%20R10%0A%0ARelease%20Date%3A%2031-10-2018%0A%0ABuild%20No%3A%201.0%0A%0ABuild%20Date%3A%2031-10-2018&pucChangePasswordState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucPassw"
		"ordChangeState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionCheckState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_209%2C1_217%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_216%2C1_198&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_17%2C1_14%2C1_16%2C1_13%2CImages%2FIcons%2FETP_icon.ico%2CStyles%2FUserLogin.css%2CStyles%2FMaster.css%2CStyles%2FCommon.css%2CFont%2Ffonts.css%2CStyles%2FBusinessRule.css%2CStyles%2FLogin_style.css%2CStyles%2FloadingPanel.css&__CALLBACKID=cmbFacility&__CALLBACKPARAM=c0%3ALECC%7C3%3B888%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

	lr_end_transaction("ETP_NormalUserCreation_02_LoginDetails",2);

	lr_think_time(2);
	
	lr_start_transaction("ETP_NormalUserCreation_03_ClickLogin");

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");


 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter_1",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"RequestUrl=*/UserLogin.aspx*",
		"LAST");

	web_submit_data("UserLogin.aspx_4",
		"Action=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Method=POST",
		"EncodeAtSign=YES",
		"RecContentType=text/html",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Snapshot=t108.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=__EVENTTARGET", "Value=", "ENDITEM",
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM",
		"Name=__VIEWSTATE", "Value={CorrelationParameter}", "ENDITEM",
		"Name=__VIEWSTATEGENERATOR", "Value=286ECC0B", "ENDITEM",
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM",
		"Name=txtUserName$State", "Value={&quot;rawValue&quot;:&quot;Admin&quot;}", "ENDITEM",
		"Name=txtUserName", "Value=Admin", "ENDITEM",
		"Name=txtPassword$State", "Value={&quot;rawValue&quot;:&quot;etp@123&quot;}", "ENDITEM",
		"Name=txtPassword", "Value=etp@123", "ENDITEM",
		"Name=cmbDivision$State", "Value={&quot;rawValue&quot;:&quot;India Retail(888)&quot;}", "ENDITEM",
		"Name=cmbDivision_VI", "Value=888", "ENDITEM",
		"Name=cmbDivision", "Value=India Retail(888)", "ENDITEM",
		"Name=cmbDivision$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:554:314:1:289:124:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbDivision$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;LECC|0;;&quot;}", "ENDITEM",
		"Name=cmbDivision$DDD$L", "Value=888", "ENDITEM",
		"Name=cmbFacility$State", "Value={&quot;rawValue&quot;:&quot;Retail Unit(202)&quot;}", "ENDITEM",
		"Name=cmbFacility_VI", "Value=202", "ENDITEM",
		"Name=cmbFacility", "Value=Retail Unit(202)", "ENDITEM",
		"Name=cmbFacility$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:555:367:1:289:172:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbFacility$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;LECC|3;888;&quot;}", "ENDITEM",
		"Name=cmbFacility$DDD$L", "Value=202", "ENDITEM",
		"Name=btnLogin", "Value=LOGIN", "ENDITEM",
		"Name=pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucMessageWarningMsgCubeState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucConfirmMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucVersionInfoState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucVersionInfo$ASPxPanel1$aspxVersionMemo", "Value=Product version: V5.5 R10\r\n"
		"\r\n"
		"Release Date: 31-10-2018\r\n"
		"\r\n"
		"Build No: 1.0\r\n"
		"\r\n"
		"Build Date: 31-10-2018", "ENDITEM",
		"Name=pucChangePasswordState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucPasswordChangeState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucDivisionCheckState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_209,1_217,1_190,1_223,1_208,1_206,1_288,1_212,1_216,1_198", "ENDITEM",
		"Name=DXCss", "Value=1_40,1_50,1_51,1_4,1_17,1_14,1_16,1_13,Images/Icons/ETP_icon.ico,Styles/UserLogin.css,Styles/Master.css,Styles/Common.css,Font/fonts.css,Styles/BusinessRule.css,Styles/Login_style.css,Styles/loadingPanel.css", "ENDITEM",
		"LAST");

	lr_end_transaction("ETP_NormalUserCreation_03_ClickLogin",2);

	lr_start_transaction("ETP_NormalUserCreation_04_LoginPopupYES");

 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter_2",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/HomePage.aspx*",
		"LAST");

	web_reg_find("Fail=NotFound",
         "SaveCount=LoginCount",
         "Search=Body",
		"Text=About",
		"LAST");

	web_submit_data("UserLogin.aspx_5",
		"Action=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Method=POST",
		"EncodeAtSign=YES",
		"RecContentType=text/html",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Snapshot=t109.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=__EVENTTARGET", "Value=", "ENDITEM",
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM",
		"Name=__VIEWSTATE", "Value={CorrelationParameter_1}", "ENDITEM",
		"Name=__VIEWSTATEGENERATOR", "Value=286ECC0B", "ENDITEM",
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM",
		"Name=txtUserName$State", "Value={&quot;rawValue&quot;:&quot;Admin&quot;}", "ENDITEM",
		"Name=txtUserName", "Value=Admin", "ENDITEM",
		"Name=txtPassword$State", "Value={&quot;rawValue&quot;:&quot;etp@123&quot;}", "ENDITEM",
		"Name=txtPassword", "Value=etp@123", "ENDITEM",
		"Name=cmbDivision$State", "Value={&quot;rawValue&quot;:&quot;India Retail(888)&quot;}", "ENDITEM",
		"Name=cmbDivision_VI", "Value=888", "ENDITEM",
		"Name=cmbDivision", "Value=India Retail(888)", "ENDITEM",
		"Name=cmbDivision$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbDivision$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;LECC|0;;&quot;}", "ENDITEM",
		"Name=cmbDivision$DDD$L", "Value=888", "ENDITEM",
		"Name=cmbFacility$State", "Value={&quot;rawValue&quot;:&quot;Retail Unit(202)&quot;}", "ENDITEM",
		"Name=cmbFacility_VI", "Value=202", "ENDITEM",
		"Name=cmbFacility", "Value=Retail Unit(202)", "ENDITEM",
		"Name=cmbFacility$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbFacility$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;LECC|3;888;&quot;}", "ENDITEM",
		"Name=cmbFacility$DDD$L", "Value=202", "ENDITEM",
		"Name=pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucMessageWarningMsgCubeState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucConfirmMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:508:261:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucConfirmMessage$ASPxPanel4$btnConfirmYes", "Value=Yes", "ENDITEM",
		"Name=pucVersionInfoState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucVersionInfo$ASPxPanel1$aspxVersionMemo", "Value=Product version: V5.5 R10\r\n"
		"\r\n"
		"Release Date: 31-10-2018\r\n"
		"\r\n"
		"Build No: 1.0\r\n"
		"\r\n"
		"Build Date: 31-10-2018", "ENDITEM",
		"Name=pucChangePasswordState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucPasswordChangeState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucDivisionCheckState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_209,1_217,1_190,1_223,1_208,1_206,1_288,1_212,1_216,1_198", "ENDITEM",
		"Name=DXCss", "Value=1_40,1_50,1_51,1_4,1_17,1_14,1_16,1_13,Images/Icons/ETP_icon.ico,Styles/UserLogin.css,Styles/Master.css,Styles/Common.css,Font/fonts.css,Styles/BusinessRule.css,Styles/Login_style.css,Styles/loadingPanel.css", "ENDITEM",
		"LAST");

 

if (atoi(lr_eval_string("{LoginCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_04_LoginPopupYES",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_04_LoginPopupYES",1);
        return(0);
         }

	lr_think_time(2);
	
	lr_start_transaction("ETP_NormalUserCreation_05_ClickPromotion");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));



 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter_3",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"RequestUrl=*/BusinessRule.aspx*",
		"LAST");

	web_url("BusinessRule.aspx", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/BusinessRule.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx", 
		"Snapshot=t110.inf", 
		"Mode=HTML", 
		"LAST");

	web_convert_param("CorrelationParameter_3_URL2",
		"SourceString={CorrelationParameter_3}",
		"SourceEncoding=HTML",
		"TargetEncoding=URL",
		"LAST");

	(web_remove_auto_header("Upgrade-Insecure-Requests", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Origin", 
		"http://172.24.1.129");

	web_custom_request("BusinessRule.aspx_2",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/BusinessRule.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/BusinessRule.aspx",
		"Snapshot=t111.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_3_URL2}&__VIEWSTATEGENERATOR=A856AE6F&__VIEWSTATEENCRYPTED=&hdfSaveMode=&hdfValidateEvent=&hdfMaxBusinessRuleID=679&hdfBRStatus=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBRefresh=1&hdnTBfacebook=1&hdflblBRName=&hdnlblBRTwitter=&hdftextCounter=&hdfUserId=&hdfLanguageId=&hdfHelp=1&hdfPrint=1&hdfCopy=1&hdfConditionBuilder=1&hdfCheckStatus=&hdfToExcute=&hdfIsReplicated=&hdfMoniterLevel=&hdfIsEnableToExectue=&hiddenfieldToUseCallbackPanel=&hdnLastScrollBRId=&hdnPreviousBRId=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=BR%20ID%20OR%20Name&trlBusinessRule=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B6bHM2ViuyEENuFja9YcxxMUvTgYTvmKb8GAZbWsg8prP4PS0a3nsiQrbzLab%2F0e56fBwTyInvrzp21G9M1cRg9iPtdioFXWTaZH6bm%2FKjrx4CFL7J99fgQb8ShvpwQ6s3VmyjbgnGuUXR%2BUOb9PriC8R90UkHW3RsD2cy5ZCYtVdE%2BgASB9BOxcJm"
		"DeA3jaira1Ct6Hxp5RREiteaCfJbujLBcdzP7TvfyXLPqYeCj77c%2F7NC45CM2plcxUxxh52aETG68seOfn6zYOnz1uNwIlVIRQzcvPdk%2BNjEu5An7E%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-679-1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtRuleID=&txtBusinessRuleName=&txtBusinessRuleDescription=&cmbBRStatus_VI=&cmbBRStatus=&cmbBRStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbBRStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbBRStatus%24DDD%24L=&cmbStrategy_VI=&cmbStrategy=Select&cmbStrategy%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStrategy%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStrategy%24DDD%24L=&chbRewardAccumulationTypePromotion=I&cbEnableExecutionStore=I&chbManualOverrid"
		"e=I&chbDiscountOnDiscountedItem=I&chbUserTimeHierarchyCB=I&chbHeaderdiscountOnPromoItem=I&txtTargetSale=&spePriority=0&trvApplicationEvents=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3BT%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0_2%26quot%3B%3A%26quot%3BU%26quot%3B%2C%26quot%3BN0_0%26quot%3B%3A%26quot%3BU%26quot%3B%2C%26quot%3BN0_3%26quot%3B%3A%26quot%3BU%26quot%3B%2C%26quot%3BN0_1%26quot%3B%3A%26quot%3BU%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%5D%7D&cmbReason_VI=&cmbReason=&cmbReason%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbReason%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbReason%24DDD%24L=&pucBusinessRuleState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0"
		"%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageAlertTimeRangeState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageAlertHappyhourState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucRefreshBusinessruleState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageCopyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageDeleteRefreshState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageShowDuplicateItemState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A"
		"-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLockedMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucPostToFaceBookState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucPostToFaceBook_ASPxPanel5_cmbPageNames_VI=&pucPostToFaceBook%24ASPxPanel5%24cmbPageNames=&pucPostToFaceBook%24ASPxPanel5%24cmbPageNames%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucPostToFaceBook%24ASPxPanel5%24cmbPageNames%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&p"
		"ucPostToFaceBook%24ASPxPanel5%24cmbPageNames%24DDD%24L=&pucPostToFaceBook%24ASPxPanel5%24memoMessage%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucPostToFaceBook%24ASPxPanel5%24memoMessage=Plese%20enter%20message&pucPostToFaceBook%24ASPxPanel5%24ucFaceBook=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucPostToTwitterState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucPostToTwitter%24ASPxPanel6%24memoMessageTwitter%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucPostToTwitter%24ASPxPanel6%24memoMessageTwitter=Please%20enter%20message&pucPostToTwitter%24ASPxPanel6%24ucTwitter=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucCopyBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucCopyBR%24ASPxPanel7%24cbCopyBROnDifferentDivFac=I&pucCopyBR%24ASPxPanel7%24cmbDivision%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B"
		"%7D&pucCopyBR_ASPxPanel7_cmbDivision_VI=&pucCopyBR%24ASPxPanel7%24cmbDivision=Select%20Division&pucCopyBR%24ASPxPanel7%24cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucCopyBR%24ASPxPanel7%24cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucCopyBR%24ASPxPanel7%24cmbDivision%24DDD%24L=&pucCopyBR%24ASPxPanel7%24cmbFacility%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucCopyBR_ASPxPanel7_cmbFacility_VI=&pucCopyBR%24ASPxPanel7%24cmbFacility=Select%20Facility&pucCopyBR%24ASPxPanel7%24cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucCopyBR%24ASPxPanel7%24cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucCopyBR%24ASPxPanel7%24cmbFacility%24DDD%24L=&pucCopyBR%24ASPxPanel7%24txtCopyBusinessRule=&pucBRPrintState=%7B"
		"%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucBRPrint%24ASPxPanel9%24grvBRPrint=%7B%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Blgk0MQsuJPkPGD6qp1wxt2J0%2FGORKOQqMjDgs%2FXdVjoD6oR6nlfFMwKv68aQKWHuvSKXQ9No7PTbsOpiswx86WWJPtLh1SdmyKO04Iy%2ByC9IK3naZWw5eyCi9IvTyfDCKJhX1SmNneFxEXBIFmvnaZWxxRBJkDq4c30Kp6qhcav1qqpbNeDhE49l92FnX60nbBx2EASRKaC%2FTbU7vYakQZE8gL4S0BUvKFrpkn6maXGZMno0e7Hw8SHzB8xau8dN3Hk%2Bd2ZsrFyP4hBuyQ8HxPIZqdsBfAZTJVbBf1%2BTq%2Buq7DZprYANoSmY4tpV6B94kXxUS31%2ByJzNgPjS1uGCFmeiXU8U6J9dqzbhtDuKl%2BOvtD8X0AJf96b0MMaJ7cdAp%2BcCil1phRfraTVObpQKrbU17Uh9S6xomSBu83Do%2BlEZMXEHvFpUJMRwDQJg5dtyEgT1K3fTWaFCOCfygBbXwrtCP30EYbPVICF2I5AfzRvSoRQfVTk7O0uUvp05%2FmWd8aa8JSq7wT9nDsIRIbl6WoZUJsoQOwlH3YAjYSJw3Lc%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucCondit"
		"ionBuilderState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStrategyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucReplicatedState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucConfirmXMLUploadState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucImportPromotionsXMLState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucImportPromotionsXML%24ASPxPanel18%24UploadControlXML=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucValidityCheckState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucValidityCheck%24ASPxPanel15%24grid=%7B%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%"
		"3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bcl3oV69dL%2FcHtCMk0ikaZJGBiyiK5yEEb27CJzKdtkSAvA%2FuLlZ%2B7zHMcwiUADUq7hM953IdMdbtm4oiZLBMPqGyos7OXf7%2Bi34OZL2B%2BayuLGf5pZQJju8%2BK5tSkOfb1AL7LK5GBlLDTPckaVe5mEhCAplp%2FOcuLht2BN%2BUWwz96apskQmHohijPFoJeQtv6BsEo3jw44CC9bmr9GuTQqAr%2BCyhqZWeFPxLXrjMP1Bs2XOoe1EyoSHHUmUnVxg2tBKkeSZg5BenC20TPN90utHER3ZnQziZ84yi4lAJc2Jn91sCjrnbUVgLJZMmLkO5emi5RYY7fDxd6utFjv6j1zTisY19pIDmPZcko22NWX5p5wB1Ugt%2BTtUV%2BeuvtFXQs2DkjdcCkGW4BjGGnHUYgS5zP6UolozAIOS%2FQatHmrg%2Bc9wfnHhwo0UdYUp1ApeBoqEFYtlFNShJcYl%2FZNa3nqQVG4o50GQODV%2FZbHFDhJQtRk9RF74i9YTaEj1ESn1ppQrKSypdLoPEreYFq47%2BEyAdzdIJ5SMKYeCnIXlT0IKSm%2BzdYtp92wx5EJ2fsJyC8H8s3tx8O5Qi8GLxkR2k2Q%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucSetWatcherState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucSetWatcher%24ASPx"
		"Panel21%24aspxGridWatchers=%7B%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BWfjGJ98CqU%2BEWOH0Y80UDLvgd5Hvh1Rq%2BFTjC5Ul7QvmUEnoG3oXWSDlKya8Q6lrX0Ql9gJy%2F32U%2B43aWDttf6HoPGB5jIK5%2BysHQULdwle9y6UlnoP%2F1CramTjUo%2Fmjtmgyobp0kbjSNLZ4j5etlDKzWr1FTDeJPhyf5vQphWepNO7fWC8Q1SiL8%2BJLATfha213XTTo9OMIdORGsPM6TBq0Ey4fxRh7F5WJdsNvLn23oVVUbzHQPMYqZQpA6Mpldtc0FfHebdIuiySdazkGxRY57jRCvnKtSsdX9VY5Ak4mZJTnVJAJFxlghnBtAd%2BPNb2FfR5ZKN1A7wIkHwBFmlguYv00VL7bGk72bOv0I%2BhdE7G5QB7n7Dh6H5fmrUz%2F%2Bcc89pQpju1PabCoxXOOwu2vYmtWg9TIc6Rjps1q2i5arqoEVsNqruVQB%2FNKxRdq%2BqCmxAtKTbVN76LkzMnUpg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucSetWatcher%24ASPxPanel21%24aspxGridNonWatchers=%7B%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BvClSv%2FIar2uVqph"
		"Ie7YwYMhDZAjKBX6yBSQ4y5VB0KWEjfV4J7QS61uQ4an5KBKGhSQKCdZSldekT4WSFNWGzktCQPJ0w4yQwYP5O0kZ%2FznS1sLptkJHxnkQ%2FeX%2FZaxfKTI3nq9bIp9MVGoyFj3IQGOmzdEs%2Br2FZ%2FzXputG9LgNLp4JO7DbkE2TzseITGfEMvrsWrVGAiDVfIwM260wSLsQEGQIMcQDgXYqt2JpgY1eYhOTzpD2Down7nnHGsJtN%2F2WL6PKr%2FO%2F6VlZjwPwpMSz%2FZNgE8NuG%2FXMf27esbTsm41t4%2FpWmxkDzURhIB9bgs9u1J6dhStfhZN1yBXLlID5U4N9tA4rTkh06%2B0yPdU%2BJ9TLcqQnQ1zv24X3efxKoZCiO3O2RinGfc84euDLwnjUjK3BtkuwRLkUp16bjV%2FT1RhWQN4J7QndqN01B4TOTBp5bfEHCfUBb0rZJloHew%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_215%2C1_302%2C1_303%2C1_261%2C1_258%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_239%2C1_247%2C1_257%2C1_245&DXCss=1_40%2C"
		"1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C0_3132%2C0_3266%2C0_3136%2C0_3270%2C1_22%2C1_21%2Cbootstrap%2Fcss%2Faaddbb1.min.css%2Cbootstrap%2Fcss%2Fcommon.css%2CStyles%2FBusinessRule.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=trlBusinessRule&__CALLBACKPARAM=c0%3A4%20999-888-202-679-1",
		"LAST");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("GetValidityPeriod", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/BusinessRule.aspx/GetValidityPeriod", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/BusinessRule.aspx", 
		"Snapshot=t112.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={'CompanyID':999 , 'DivisionID':'888' , 'FacilityID':'202' , 'BusinessRuleID':679 , 'VersionID':1  }", 
		"LAST");

	lr_end_transaction("ETP_NormalUserCreation_05_ClickPromotion",2);

	lr_think_time(2);
	
	lr_start_transaction("ETP_NormalUserCreation_05_ClickUser");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_add_header("Upgrade-Insecure-Requests", 
		"1");


 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter_4",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"LAST");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"SaveCount=UserRightsCount",
		"Text=User Rights",
		"LAST");


web_url("User.aspx",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx", 
		"Snapshot=t113.inf", 
		"Mode=HTML", 
		"LAST");

	web_convert_param("CorrelationParameter_4_URL2",
		"SourceString={CorrelationParameter_4}",
		"SourceEncoding=HTML",
		"TargetEncoding=URL",
		"LAST");

	web_add_auto_header("Origin", 
		"http://172.24.1.129");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

 
# 405 "Action.c"
	web_reg_async_attributes("ID=LongPoll_0", 
		"Pattern=LongPoll", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"RequestCB=LongPoll_0_RequestCB", 
		"ResponseCB=LongPoll_0_ResponseCB", 
		"LAST");

	web_custom_request("GetApplicationTextMultiligual", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx", 
		"Snapshot=t114.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={'TextId':'50006'}", 
		"LAST");

 


	 
# 440 "Action.c"

 


	 
# 457 "Action.c"

 


	 
# 474 "Action.c"

 


	 
# 491 "Action.c"

 


	 
# 508 "Action.c"

 


	 
# 525 "Action.c"

 


	 
# 542 "Action.c"

 


	 
# 559 "Action.c"

 


	 
# 576 "Action.c"

 


	 
# 593 "Action.c"

 


	web_stop_async("ID=LongPoll_0", 
		"LAST");

 
# 612 "Action.c"
	web_reg_async_attributes("ID=LongPoll_1", 
		"Pattern=LongPoll", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"RequestCB=LongPoll_1_RequestCB", 
		"ResponseCB=LongPoll_1_ResponseCB", 
		"LAST");

	web_custom_request("GetApplicationTextMultiligual_12", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx", 
		"Snapshot=t125.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={'TextId':'50006'}", 
		"LAST");

 


	 
# 647 "Action.c"

 


	 
# 664 "Action.c"

 


	 
# 681 "Action.c"

 


	 
# 698 "Action.c"

 


	 
# 715 "Action.c"

 


	 
# 732 "Action.c"

 


	 
# 749 "Action.c"

 


	 
# 766 "Action.c"

 


	web_stop_async("ID=LongPoll_1", 
		"LAST");

	web_custom_request("GetApplicationTextMultiligual_21", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx", 
		"Snapshot=t134.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={'TextId':'99901'}", 
		"LAST");

	web_custom_request("GetApplicationTextMultiligual_22", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx", 
		"Snapshot=t135.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={'TextId':'4009'}", 
		"LAST");

 

	if (atoi(lr_eval_string("{UserRightsCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_05_ClickUser",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_05_ClickUser",1);
        return(0);
         }

	lr_think_time(2);
		
	lr_start_transaction("ETP_NormalUserCreation_06_ClickNewUser");
	
	
	(web_remove_auto_header("X-Requested-With", "ImplicitGen=Yes", "LAST"));

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"SaveCount=LoginNameCount",
		"Text=LoginName",
		"LAST");

	web_custom_request("User.aspx_2",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t136.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8C"
		"H6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws"
		"3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVi"
		"rgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=&txtPassword=&txtConfirmPassword=&txtFirstName=&txtLastName=&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=&cmbLanguage=&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot"
		"%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=&cmbSkin_VI=&cmbSkin=&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=&cmbUserType_VI=&cmbUserType=&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=&txtEmailId=&cmbCompany_VI=&cmbCompany=&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot"
		"%3B%7D&cmbCompany%24DDD%24L=&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=U&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A10"
		"0%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%"
		"2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2"
		"nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%"
		"3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26"
		"quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMb"
		"xIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2"
		"C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbptrlUserList%24trlUserList&__CALLBACKPARAM=c0%3A4%201",
		"LAST");

	web_custom_request("User.aspx_3",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t137.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8C"
		"H6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws"
		"3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVi"
		"rgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLangua"
		"ge%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0"
		"%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-100"
		"00%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B12"
		"00%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZg"
		"Zk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacility"
		"Rights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B"
		"%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BZxz5u08JmBTuf%"
		"2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_"
		"190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cmbDivision&__CALLBACKPARAM=c0%3ALECC%7C5%3B999%7C0%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

	web_custom_request("User.aspx_4",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t138.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8C"
		"H6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws"
		"3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVi"
		"rgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLangua"
		"ge%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0"
		"%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1"
		"%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quo"
		"t%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjO"
		"HsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&"
		"pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate"
		"%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26qu"
		"ot%3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%"
		"2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cmbFacility&__CALLBACKPARAM=c0%3ALECC%7C3%3B0%7C0%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");


	

	web_custom_request("User.aspx_5",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t139.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4Ksrs"
		"Zdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV"
		"4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBI"
		"OPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cm"
		"bLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=neha.priyadarshni%40etpgroup.com&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-"
		"1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3Bwindow"
		"sState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200"
		"%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ"
		"9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000"
		"%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrat"
		"egyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%2"
		"6quot%3BcallbackState%26quot%3B%3A%26quot%3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17"
		"%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbpNewUserTab&__CALLBACKPARAM=c0%3A",
		"LAST");

	web_custom_request("User.aspx_6",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t140.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4Ksrs"
		"Zdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV"
		"4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBI"
		"OPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cm"
		"bLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=neha.priyadarshni%40etpgroup.com&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-"
		"1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3Bwindow"
		"sState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200"
		"%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ"
		"9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000"
		"%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrat"
		"egyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%2"
		"6quot%3BcallbackState%26quot%3B%3A%26quot%3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17"
		"%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbptrlUserList&__CALLBACKPARAM=c0%3Afalse",
		"LAST");


	web_custom_request("User.aspx_7",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t141.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4K"
		"srsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZ"
		"qKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQ"
		"SBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=&txtFirstName=&txtLastName=&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=&cmbLanguage=&cmbLanguage%24DDDState=%7B"
		"%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=&cmbUserType=&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=&txtEmailId=&cmbCompany_VI=&cmbCompany=&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCal"
		"lback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplit"
		"terLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0"
		"%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU"
		"2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3Bwindo"
		"wsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%2"
		"5%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9"
		"nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_30"
		"2%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbpValidatePassword&__CALLBACKPARAM=c0%3A",
		"LAST");

	web_custom_request("User.aspx_8",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t142.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4K"
		"srsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZ"
		"qKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQ"
		"SBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLan"
		"guage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A784%3A159%3A1%3A501%"
		"3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1"
		"%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quo"
		"t%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjO"
		"HsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&"
		"pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate"
		"%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26qu"
		"ot%3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%"
		"2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cmbDivision&__CALLBACKPARAM=c0%3ALECC%7C3%3B786%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

	web_custom_request("User.aspx_9",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t143.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4K"
		"srsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZ"
		"qKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQ"
		"SBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLan"
		"guage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A159%3A1%3A501%3A1"
		"65%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A"
		"0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3"
		"B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsm"
		"tCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&puc"
		"DivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26"
		"quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%"
		"3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1"
		"_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy&__CALLBACKPARAM=c0%3AKV%7C2%3B%5B%5D%3BFR%7C2%3B-1%3BGB%7C19%3B14%7CCUSTOMCALLBACK0%7C%3B",
		"LAST");

	web_custom_request("User.aspx_10",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t144.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2BfoAcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4K"
		"srsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZ"
		"qKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvDr9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQ"
		"SBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLan"
		"guage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A159%3A1%3A501%3A1"
		"65%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A"
		"0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3"
		"B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsm"
		"tCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&puc"
		"DivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bst"
		"ate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%2"
		"6quot%3BZxz5u08JmBTuf%2B94W%2Frxfs1eQYnCSWp14u8r%2Fae5q2MqmL3FeK1WWt9oZWnGFXBMnMST9jUWs9nyrXoNznZvZsWz7myn%2FrwMnRGn3wFncUZLJVPA6w7drpIFVTZjQURJwf1atZ2pTubvgySSBMbxIeTxV%2FY34SjyjyUIPBM5TimtA7R5W2JOtOSAePxP14aC%2FinaBnsPwGpo%2FjDEsmTCo9Y0M4RO6ZGhd3COcjIXQ%2BiAtSiUwesA7S0V9R9gXTr6DYMwGqKlrggWpO979qDYJQYUnjGTjAz4%2B6ICZTYPdQjTEPCFht4B3TunUxPhX%2F0kXeenJeV0dY%2FupH2s2XYZM0XGe7ealW%2FXctrVXsE4GVDH51apUcB0kFNFF5xexsWH8MVvAKQCT9%2Fc%2BPwqtonnS8PvYETNIWGWp6FxLCNZ%2B3f3cG39sr0PWdMOPCS0Td8R5tsT%2BQb2jczjS4xilYBft6C%2FdG8TdWrmccpL6S%2FW9i1VF7Y1%2BzpswGuUUSdAZdYtwAO115qNJdaLl8WvgOS4sA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_2"
		"56%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=pucLocHierarchy&__CALLBACKPARAM=c0%3A-1%3B",
		"LAST");

	web_custom_request("User.aspx_11",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t145.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2Bfo"
		"AcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7"
		"ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvD"
		"r9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is"
		"%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0"
		"%3A0%3A-1%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%"
		"26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C"
		"1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fgl"
		"r9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-100"
		"00%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrate"
		"gyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26"
		"quot%3BcallbackState%26quot%3B%3A%26quot%3Btwr%2BDRUO00u2jK23rdhylCRHFHZ15GTV8A%2BXDArfvFmyjIoaLP5gBN6XJixURP%2FRup1cEl1htmuub0Z0d4fFNCRCVxooQ9ChJYNOl9MVlDeGt2Bq7ikzAjx%2FbR9usrvyMTBCNwEtInrooYXhPWG1LiUkILSCS3hwh3y9d1gKzbB3QzE1tSa7CbJDKiqSBZ%2BZ9zx60vqoSK%2Flnf%2FH45uwrzvmVNBtTGz5NF%2FD35XZ1QSW9NlPTYwRR7QSXn66y%2ByHtnuUQUZQWWcM4czpfQNxWzm2%2BpQoGSg6IWaHsyLj11BmBZIa9q4J2YA5WdtazmOyzLbMi%2B3v4%2Br9fCRRvs5EFnn%2FwOpMqJ83pYo7rAI4EzLQwajwoM%2FhI9zD5YJlv0q0W7eu%2BcCCRvihrl5SrpoIgIT8Dzv8jQBTdiRT1pQPqX1XuGCjmgiXuRWAkpsDCSh1Jbe5QX45p%2BD67ZhA7Ej9ORUUki%2Fo9fn%2B1Fi%2FoOq2Z3c%2BOY0svM0StdOF9e9YrG6a5Da0Um2mvFsLeLaQ%2BbpawqIHKGBltc8Fm9v3R8fWAnoOHQeme3JSPsEwadKlZKNW%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_21"
		"7%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbpSelectHierarchy&__CALLBACKPARAM=c0%3A%3BLOC%7C1%7CN%7C%7CAll%20Locations",
		"LAST");

	web_custom_request("User.aspx_12",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t146.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2Bfo"
		"AcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7"
		"ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvD"
		"r9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is"
		"%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0"
		"%3A0%3A-1%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%"
		"26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C"
		"1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fgl"
		"r9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-100"
		"00%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrate"
		"gyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26"
		"quot%3BcallbackState%26quot%3B%3A%26quot%3Btwr%2BDRUO00u2jK23rdhylCRHFHZ15GTV8A%2BXDArfvFmyjIoaLP5gBN6XJixURP%2FRup1cEl1htmuub0Z0d4fFNCRCVxooQ9ChJYNOl9MVlDeGt2Bq7ikzAjx%2FbR9usrvyMTBCNwEtInrooYXhPWG1LiUkILSCS3hwh3y9d1gKzbB3QzE1tSa7CbJDKiqSBZ%2BZ9zx60vqoSK%2Flnf%2FH45uwrzvmVNBtTGz5NF%2FD35XZ1QSW9NlPTYwRR7QSXn66y%2ByHtnuUQUZQWWcM4czpfQNxWzm2%2BpQoGSg6IWaHsyLj11BmBZIa9q4J2YA5WdtazmOyzLbMi%2B3v4%2Br9fCRRvs5EFnn%2FwOpMqJ83pYo7rAI4EzLQwajwoM%2FhI9zD5YJlv0q0W7eu%2BcCCRvihrl5SrpoIgIT8Dzv8jQBTdiRT1pQPqX1XuGCjmgiXuRWAkpsDCSh1Jbe5QX45p%2BD67ZhA7Ej9ORUUki%2Fo9fn%2B1Fi%2FoOq2Z3c%2BOY0svM0StdOF9e9YrG6a5Da0Um2mvFsLeLaQ%2BbpawqIHKGBltc8Fm9v3R8fWAnoOHQeme3JSPsEwadKlZKNW%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_21"
		"7%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy&__CALLBACKPARAM=c0%3AKV%7C2%3B%5B%5D%3BFR%7C2%3B-1%3BGB%7C13%3B10%7CCANCELEDIT%3B",
		"LAST");

	

	web_custom_request("User.aspx_13",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t147.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2Bfo"
		"AcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7"
		"ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvD"
		"r9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is"
		"%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0"
		"%3A0%3A-1%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%"
		"26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C"
		"1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fgl"
		"r9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-100"
		"00%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrate"
		"gyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26"
		"quot%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C"
		"1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbpLocation&__CALLBACKPARAM=c0%3A",
		"LAST");

 

	if (atoi(lr_eval_string("{LoginNameCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_06_ClickNewUser",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_06_ClickNewUser",1);
        return(0);
         }
	
	
	lr_think_time(2);

	lr_start_transaction("ETP_NormalUserCreation_07_ClickSave");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"SaveCount=SuccessfullyCount",
		"Text=successfully",
		"LAST");

	web_custom_request("User.aspx_14",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t148.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2Bfo"
		"AcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7"
		"ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvD"
		"r9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is"
		"%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0"
		"%3A0%3A-1%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3Bwind"
		"owsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B22"
		"00%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4Tx"
		"VJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-100"
		"00%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24spl"
		"StrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B"
		"%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_"
		"185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbpUserSave&__CALLBACKPARAM=c0%3A",
		"LAST");

	web_custom_request("User.aspx_15",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t149.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2Bfo"
		"AcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7"
		"ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvD"
		"r9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is"
		"%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0"
		"%3A0%3A-1%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3Bwind"
		"owsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B22"
		"00%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4Tx"
		"VJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-100"
		"00%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24spl"
		"StrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B"
		"%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_"
		"185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbptrlUserList&__CALLBACKPARAM=c0%3Atrue",
		"LAST");

	web_custom_request("User.aspx_16",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t150.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=New&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B3bjfIbE1GCjkc7G6M%2BhL7c64VpWRqAl1fxVNGz9Wtt1Kp%2Fly57%2BBqUXLtkD3XQdegT%2BBWj0QVssgWstJuKM1Hx8%2Bfo"
		"AcWjV8E%2FUKbVqgO2ZXJRv9MEqt7URcy4KsrsZdq3Z8CH6O2JkUznSqkUXdaJX4o%2BxubYZINHUsPLV57O%2FVTyuU%2BxcDFHVrL8eBSg%2F75vDGujUR1%2BSgVnj0HF%2F8p1%2FqoBr2pFkZhqxBs6C8vr%2FFjF73dJ5pMHyaIhI5xiYdgRCNVwzUtB76pTc3MsRN32lVZe0wWVJfWiOqUg029wsFywrt1stJoyLDo9%2Br%2BY7Sz%2BFNQps8ICOBeKhy0jrjfiVhpYPMJume3D5kQhb%2FayZwMYJXEBR6%2BPoYBRbeY3odfXTVHaM527OpZb0uOzLme19YXN%2BximoFWqvixhnLkKqx9nA%2BfNr1d6Lznj5aKxIQRLyMcv6utGp1L5kaTzazVnFDS7e9PMawX3Ns0002w0UMVP1ek0Jk%2FU%2B7vMH4oenCfYaG4kviTfES7ws6r5C6gszO55EY6mo9y3hp4oSgkYx9quHU%2F5kpHrQVv1sGwrmXJ%2Bn%2BdivTMEHrU98BJafgryvHuET4GatSYKkx2cOECZ6RrMQ4U4Cm%2BeTzH8DAv4k6VCK9KV6JIbeJxCbRRusurN1tc6uuoat1grgUZ1YwvAEizsPlhk3R8tVszsPIsbH6XY3es1pKx4muONGjxL8bJDAhd%2Fjar2w9La4ktFWnW4WG5n7k3qG55vX9AtuJeqvAxDvH5Wq6Lyttk%2BUBdwMF6%2BOgh5gSFk4kIa3PliogIVaDSh9sdCR1vqdZiJOd9sRbBaNHExqBnTLuQ0dQJ6mxRFJMugrmRBnsm4KkeW%2BTlSIgv6lvOxgzSjkPEoleHAWKNXs9XTi1qdztfnz%2FaqX8mEnckdaBi1MCgfT5wzPZW6MYsIjZG4SK5sA71AzPXc%2FzIvbfiAtmGU2a7CDtLEjLnZIyFXwp63Z2OU%2F899bpamBbi1bFM5hzbt7P%2FEnALRdWQ4tZLfGaDdSBYxdIsb6nbiUxiYi7"
		"ZlFPyrzUZ%2FGDOd1XBWUMB6xxmdKHVqRtZqKV4OMMuws3GiGm2tskAjxGezrzb8%2FZaL5DO5qItaLcO%2FoowtAyJV9pyqAKIDcd857fv3P6tVhb9cpFw5HJH1kn%2BgwywotVwR1j%2B5j80bjTI1NbcVUkgQ%2B647fmAu0o5mQ8bQZ5VpWBkyaHcoUIlRjaixFvIHK%2BzQGQPF7uKbZaLxrE%2B3XtBS47wMOGqs2N61pMyAUN%2F%2F4MVfdU012WZ8oQ1AYs2zZLdqGKjGheTiEKjJbRNXjSDmvUuVIiealZPcAbMX2LkDuB9R7JUgS1MLsX2%2FoRWuvzJ4Q%2Fsim%2BqlH5PID0cCRopwNPAyHOk2TyqE4KfubvSp2zpqXyMdwpFNZtnRiPOjb1O48MoD8Y3LrBFHwCevloAwBeEzUDdSbVMZPyeiLuO8ePo0vPl0zpLrMdxyOQJDpaWeR%2FODN6hJW3f02hLutoFnINfHOOgFK9VqIKg%2F2nYRzuQfvjzXvLeJOKA%2Bsyqu8HQ3XgQnhv7P0GTeJwJGf4Pa%2FjmMFne8LNmElKIkcBcEV1QB1D8d2SNyL0UL2uYnk4BLk8du%2FBt7fgXh4SobbFbJhnzqOUzOq2Q0w1zsEsf4aqcfd2PlKq4JQRMprqL9cbQRFLoEsh8FoVQFu0m1dsdlNtuKvTZYE%2FoYKEeGGEr%2BcE2OpEixNoLCihEq%2BqyoEWEohtlFwF458CKQEfQKpcA%2BKGxD3CEbnHu9Tcs1NRSrR%2F91qjdZZNGTfNiT8f%2FpzSotcylCW3PLkDRxLrstNQh6jPqEKnE8WgrAYKVJsilntq69ckypVLuKenq%2FNBJZOh%2Byn7RJA66WcjFOjuCeXLIy6jfXPWTKEFVE1dWjlmgADqDVfhFKiYjw3LRXKIVB6frGG%2BcyrhPxwtSqbpeN3qnUgupL6dJAlsUc63wf%2BPms5aDls4Jss2h0f1dIMJgZ1zISdGvD"
		"r9mKG0EnjElVz8EdP9aNpJlYpQk%2B85UaQSBIOPgHFVirgv7j4ppfnMnKAYPOxal9RpQuTt%2BUSQbG%2BxcYpeiIgQ6wR9jiuzx5Yw0YvnDVW%2FBxGdCRLW8XpkW5HLx1Hk8Nu%2BBW4B9A6jA0SofqAELR6RfUeua3nvCTabmjGhBOW6c1%2FuEX8lA5hqgvW4D1rBMy7CcgI1CqbTQUwbRiiorMdwytconq06%2FtMIM0GU%2FiuWBa5dBlUTZVb25vqKWCdPLNb1EjBY2EDd6Z2FeKzDIkAdinz9%2Fn9PfYJTuv43gu4HpOgfw8q29kyR%2F%2Boh86yZMq%2F6M%2Beg7Lp35TB6c72qnB%2F808upNuEka%2BnJ%2FuOS%2BouYvBH98rGtUpJ05RXKeMEKh3JGENvVagIWzBQdb8pyDhGpYaiP4SUfetbmody2ujIu%2ByK1JQqDC4ywPgjZsM5lQTVr5NyalKQRMkeCa8aH2yHhWarBQ37U5M1P5%2B4wPlGqhY5%2B7eNtjV234eWNmtZ53rGpldkzTl4OG8sA9pz1DdWlKDugU%2F8diqp%2BcJKCvDjWhGZkml6v%2F3h%2BmoRWeItqK1r4X3jRFeKhXCsn5sZ94ZJfAMTrMN7G4PXk7VQnZjxz3yqQ99PyWJoZxMCp034TOFZnkCtgc%2Bc%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is"
		"%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0"
		"%3A0%3A-1%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3Bwind"
		"owsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B22"
		"00%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4Tx"
		"VJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-100"
		"00%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24spl"
		"StrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B"
		"%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_"
		"185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbpUserSave&__CALLBACKPARAM=c1%3A",
		"LAST");

	web_custom_request("User.aspx_17",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t151.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBGOSH2%2"
		"BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2FnYOJ3X"
		"RE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2BlamNHqiFC"
		"XCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=&txtConfirmPassword=&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English&cmbL"
		"anguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0"
		"%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B786%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0"
		"%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26qu"
		"ot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2"
		"QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionF"
		"acilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%2"
		"6quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot"
		"%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C"
		"1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbptrlUserList%24trlUserList&__CALLBACKPARAM=c0%3A4%201",
		"LAST");

	web_custom_request("User.aspx_18",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t152.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBGOSH2%2"
		"BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2FnYOJ3X"
		"RE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2BlamNHqiFC"
		"XCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English"
		"&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A159"
		"%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3"
		"B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot"
		"%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxX"
		"ck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3"
		"A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLo"
		"cationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26quot"
		"%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_29"
		"8%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cmbDivision&__CALLBACKPARAM=c0%3ALECC%7C5%3B999%7C0%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

	web_custom_request("User.aspx_19",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t153.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBGOSH2%2"
		"BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2FnYOJ3X"
		"RE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2BlamNHqiFC"
		"XCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B1%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=English"
		"&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A159"
		"%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3"
		"B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot"
		"%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxX"
		"ck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3"
		"A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLo"
		"cationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26quot"
		"%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_29"
		"8%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cmbFacility&__CALLBACKPARAM=c0%3ALECC%7C3%3B0%7C0%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

 

	if (atoi(lr_eval_string("{SuccessfullyCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_07_ClickSave",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_07_ClickSave",1);
        return(0);
         }
	
	lr_think_time(2);

	lr_start_transaction("ETP_NormalUserCreation_08_EditUser");

	
	web_reg_find("Fail=NotFound",
		"Search=Body",
		"SaveCount=LastNameCount",
		"Text=LastName",
		"LAST");

	web_custom_request("User.aspx_20",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t154.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBGOSH2%2"
		"BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2FnYOJ3X"
		"RE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2BlamNHqiFC"
		"XCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=Engli"
		"sh&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=neha.priyadarshni%40etpgroup.com&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1"
		"%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsSt"
		"ate%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C"
		"0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%"
		"2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A"
		"-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splS"
		"trategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%"
		"2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_1"
		"85%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbptrlUserList%24trlUserList&__CALLBACKPARAM=c0%3A4%20108",
		"LAST");

	web_custom_request("User.aspx_21",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t155.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBGOSH2%2"
		"BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2FnYOJ3X"
		"RE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2BlamNHqiFC"
		"XCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=Default&txtPassword=etp%4012345&txtConfirmPassword=etp%4012345&txtFirstName=Test1&txtLastName=etp&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&cmbLanguage=Engli"
		"sh&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=1&cmbUserType=Admin%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=1&txtEmailId=neha.priyadarshni%40etpgroup.com&cmbCompany_VI=999&cmbCompany=Multi-national%20Retail%20Corporation&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1"
		"%3A784%3A159%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=999&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B999%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=%2C%20LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsSt"
		"ate%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C"
		"0%7C1%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%"
		"2Fglr9qvkJxXck8Pzfat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A"
		"-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splS"
		"trategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%"
		"2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_1"
		"85%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy&__CALLBACKPARAM=c0%3ASR%7C1%3BT%3BKV%7C7%3B%5B%22LOC%22%5D%3BFR%7C1%3B0%3BGB%7C24%3B14%7CCUSTOMCALLBACK5%7CClear%3B",
		"LAST");

	web_custom_request("User.aspx_22",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t156.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBGOSH"
		"2%2BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2FnYO"
		"J3XRE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2BlamNHq"
		"iFCXCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&c"
		"mbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=neha.priyadarshni%40etpgroup.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A15"
		"9%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B786%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%"
		"26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2"
		"C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pz"
		"fat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A"
		"0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHi"
		"erarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26quot%3Bcallb"
		"ackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_21"
		"1%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cmbFacility&__CALLBACKPARAM=c0%3ALECC%7C3%3B0%7C0%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

	web_custom_request("User.aspx_23",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t157.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=Default&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBGOSH"
		"2%2BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2FnYO"
		"J3XRE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2BlamNHq"
		"iFCXCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=GB&c"
		"mbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=neha.priyadarshni%40etpgroup.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A15"
		"9%3A1%3A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B786%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%"
		"26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2"
		"C%26quot%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pz"
		"fat%2BYpjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A"
		"0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHi"
		"erarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26quot%3Bcallb"
		"ackState%26quot%3B%3A%26quot%3Bv5SbMKecjYiP%2FaO4k9tj7wxMnCkb%2Bb5u5Huv5f7gmgdMZbpkCr0w%2FIj5FqVhUZxj1VNxjTrvrhA4921AaFGONMZlxb%2FPJ5dmfyZvP61vNo9X1yQHvk13Ne82b0Yr%2FpxkCIe1mJfYKIQWpcM4wBcjS%2FGj5dGILruHWmpfwCtu3YzO%2FRwreNIpLdZe0FMLkHzCyVMcS%2BVX7yPlmUsJCXADH8YQkt3AuPeBt68NibfUslkVUnjQcoZRS1UFBhifaV46GUUGCRrEYWSx8qSEN8qaS5g3lHKCt3zYE%2BoBaRIUjcQA11EZDjYMDEvHAu2UflJcNQsPjFykz9PrXmRoP2IqDO0nqvPrNSosSIWKoui6zRBRYPyFRaq3k6Z0FBsUjlZ2tajL7YAmMzM04BIaX8tePXFLJLtSUYHOQSqB3qqWvpMrNPfDGpWJra%2F5Dg63amywmQGpjwr48QHsb3ra4VfD77z3k1XlDRaSmqj74ACayd7LFyYWTmOiyXuhtOpYcDZmTE15PQI44E%2BbCXbEJfyQVM7hsE%2F%2B0LpxXjS2nlpCEHXum%2BcLlZdaQKjsnG9Dz%2FBNgU0RPX%2B2tvmvNjZw9g92%2Fg%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_21"
		"1%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cmbDivision&__CALLBACKPARAM=c0%3ALECC%7C5%3B786%7C0%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

	web_custom_request("User.aspx_24",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t158.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=PTUser{pNumber}&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBG"
		"OSH2%2BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2F"
		"nYOJ3XRE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2Blam"
		"NHqiFCXCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=G"
		"B&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A159%3A1%3"
		"A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B786%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%"
		"3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quo"
		"t%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BwDIa%2B6E8UlZFqoSvRI89EYveyBJ8QRYkONR2Kzr17lNenD3iMAZvGVPfNwVkppeke14MEqNLlNwKdYOX20x9eqnQPwdT8n8tWqKv3iQudb5%2BXCZyDiDwEP5Rp0AGWmx5bitj9%2BkBXwLQC8Fs4xZFX8SHybcXNL4qP5psvbWctcaCILeK9oC7lrJLpqUSuBxjl38X8t4hCneq0ZTbe7QAoT0h6AhqM%2Bvpfn4Q%2BKhf3ElDvG6N%2FXlT9BBFriecYcqJ5xPHytuUeqT1J8ynZ98xOQV08x0RYaApN6AwKGDr3XUOw3iRAiZqNYNPWMmr1B0lJF%2Fkdlq3yIVqRZtTqu%2BR4q9RjgnHfCFU4TxVJ9S%2Fglr9qvkJxXck8Pzfat%2BY"
		"pjal7zdkJVjOHsmtCViDwvV2QKu7ZZgZk1g0Oj0iQxP6nUFWObXaDM9lVOy2yaGU3VsNcC%2B0FyPDvTPCxAtwW9dqI3l%2BU2ipOtLxkD6t%2FkxSoZQBP7FrdrDjZ0Wz%2BvRyk897GjWBTLAs26albAGgyubwsQnqgS3SHgN2nze0i1HTiuyur%2Byeju12weZyTBkJvtRQNktNBkuwVLrBDLJCY3X9gwjyFy2JyePm1fL69vSXYZdSyCbzTU6IPKXDnEon%2BYf7Xub0G58WS8aBDNbwTcIT4tMcKu%2Fq8vB9GquAxHiw%2Bx4%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%7B%7D%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0"
		"%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHie"
		"rarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bcallba"
		"ckState%26quot%3B%3A%26quot%3B5PCvQ15EHRFKAZUigXHlVXW6bI8MMvPIHhr1DBEvE%2FXcQf%2FuHsiucqDtY5Dt6OhruDP4zLbD2D0fY2NLaz08uXHm4H0dm2lrr0Xbtxpp%2BKdi%2B%2BrxJS8ddWoh%2FRDQz7dHxXo4I6N43HS0cIjB2kukBdeMGV4pnpKmasYsNQA66TXKuMOTZcbSRceCMze4h%2BZvjh9SDvfNEV0nL0Ro4v6P0s8PMK3sV4gjL3B%2FST0cS38MflQdZVJJrDs8AutChwVMfI%2BrkpaD7i3SXMGtKYY92lE%2BRLj31cyQY80O3C7p%2BuW1Oav6FhlaHZMbVV%2FkSO4zx4e1CZRonrUXjGy1F2lJFBDgh4OXc4Nk%2FuncLs2iODWR754wdMKmfC9OJQxxWWzMEkW7s%2FXrAxvIw80uM66d93b9ZfaiqkRg%2FBBAi6S6H9C4C6dg8Fl5%2BP1fv9uH2v2nWtjnGyialZsymt7AC2oUrU%2FSI8wnWZTzuh5Eyys9lbc%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263"
		"%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=pucDivisionFacilityRights%24grvDivisionFacilityRights&__CALLBACKPARAM=c0%3AKV%7C2%3B%5B%5D%3BFR%7C2%3B-1%3BCR%7C2%3B%7B%7D%3BGB%7C19%3B14%7CCUSTOMCALLBACK0%7C%3B",
		"LAST");

 

	if (atoi(lr_eval_string("{LastNameCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_08_EditUser",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_08_EditUser",1);
        return(0);
         }
	
	lr_think_time(3);

	lr_start_transaction("ETP_NormalUserCreation_09_SaveAgain");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"SaveCount=RecordCount",
		"Text=Record successfully updated",
		"LAST");

	web_custom_request("User.aspx_25",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/User.aspx",
		"Snapshot=t159.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_4_URL2}&__VIEWSTATEGENERATOR=E7347660&__VIEWSTATEENCRYPTED=&hdnMaxUserId=&hdfClickedbutton=&hdnUserId=107&hdfSaveMode=&hdnLoginName=PTUser{pNumber}&hdnSaveFlag=&hdnEditFlag=&hdnNewFlag=&hdnPasswordFlag=&hdnConfirmPasswordFlag=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBUserRight=1&hdnTBRefresh=1&hdnTBPasspord=&hdnTBExist=&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnCompanyDivision=&hdnEmailAlerts=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtSearch=Search%20for...&cbptrlUserList%24trlUserList=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3ByhT5HyqgqpHoCwAb%2B9m5HVK6AiK7Ya8S6Alds8M5g6cF0wbLHmkq9vPfzXaul4U1A43MzTSZBG9czYt7R%2F%2FS9mJ0YBG"
		"OSH2%2BHfSttbR%2BpxAS6sBl2letxLGOGrdIQvAdyo72Kkbt3i46jsGEtv%2FBFrebjl6dEFwdTBe0MZmNKMXDfwVvCTBdPCoJ1nyi9yPx1B%2Bl8%2B1ept4nXZi%2F8bgHs%2FunhMeD9YJSTAJNu%2F2X48aydttHc9UQCOggdR32I8xqRm0HrdtNNBCtSzc55cdGWK70MStr96ZFuYWDxBUqprdvU3vHaJhVqSnBkGdKf%2FoqPfNW1Vq0D%2F4gKCOgIUuEOmkcucT5IkZ43L7p8E8pqlXoJj%2FCISmlePc%2FeI0G7XWWTInzQknIxfg9sOstdihrzORSpICWFBpUgPON%2Bzh%2Bo2Bknp3ebNp89xOaPJWXbeW09FNetn2V%2BQbg0%2Fx3Gvg2xcfbJm9bIA6LVBM8LIZ03q6KY0JbBKsz62fI0%2FHxA%2B2Ht8nQGfCfjRm5y5nZBYOQuR589YQix9Qdj69X5%2BigS0YxLMhPxG7zSjU6I9IJ5qJEHrP6ZJjcTViHsUOHNdnAYtufU4n1Lv0%2BqtVGbLd1VvO%2BxchJz7waxUfHuQQHKENdOQ9yaFG50pQQBTGqdU9ZtlWqnAPuYPBTZG2YQzm3S8oo0DidEsKkrxlaKqnYODGU3LJATPmkPbW2p5rl13DCs4nioNgvRIM6SNY8D9a7Sw1SuNOk9zU%2BpuqWW6CF%2FIFSF5jEqrFzKFU2QzUK9miGEFXtUN%2FcupdcSmh6dW8BwgWeYhEb6pEauxGZr379hNXMtwa0z1K33hNUV7NLjDoWKwLHmmD9ru3Zjmztu1RWrgsD%2FutszAlKl7JWGq30%2FsrJai%2B9ZSnaYeTswmrZ0SABUaQ89M0Z1NwFXhWeLDa2KPU7DtLuT8tIVJOyJSD19pj8vY23DZHCnn3pEBndeg8ntzAnfYRaRin9oDuQHIfPG5rclBd4WNV1L811MkyktOjlvpbYUfHyZJQA6M9iPngb5YCkLqxWR7Lth2F"
		"nYOJ3XRE2m7hOiuyUa6W5S97hBd213qnFhLQ78FMQ9%2BRtV9IBGiWCcRWb0ox5lB%2BXsxSqYhpYAB3oJaAEpUsCSOTcJAg2yZYlnbwgP7Oa8Qn1%2ByN4SI1BEls90U8rfeZNN5hqVpcMmVb4K0v4Po%2Fbwmsge44mcQYlXDHEQan6IxyILelsgmy2EjFSuN0cfOHQjf6wFavW9m2E1R3W48E514SzwV4%2F8AocpS05DpERpNtHgRm%2FH2Ili2j7nC9d5ikuAqHYdxZ2jWfojaqSubXYEw6GrqvPA1Y15bAOiA7QZSSB6hxz%2Fm38ixRrIGsZ%2BARY3aXyVZYm8ZvJq4CnhBH2Y7KUTIiEHOMLV9qAKmdFH8Nr1xjjrvRsv7s0GRM7ghZJy6TyT1oBJADQZQp5vH1VxBuUK1prZIBkdPkoe7FPoTE0hDN8b%2BvjZdzWuua%2B2XLbjkze5uyks7uGItDLEor1MF65v22dAltIlZmZ%2BTw7CkuewV8AMO9jcvZa8nAvZOg3fJqpsjCA2JcL1CqUpq6aCQKNwF9TB6XVISyPY03KqOTF3HJPXpScJU%2B4IMfSmLuYhyg%2FJ2BI7UrCqo2%2FBcgjnPFLy1jGqUMjhCA0hKThQHS6oOx0lp4BAjTWEQ00pl9tAU%2Fl8IDxvgK6TVWY0ys%2BlFpm%2F%2B43%2FER88dAaA0ALmFRXN9LA%2BWosvWmYy0Mf8DGdXe4MJFrSbSHe8rnYCd6zc06QLU9vuatESqp9JNj3E4Gt8WwK%2BPhsSCC%2BjFw6XPhfFOfm05y9EnJJxNM9XslJQqn8SlJ1VhP85%2BsBoUw469tBgsuLJ%2B%2FltPbXm8ul7YiPTwJZu4OfquKaG6M%2Batk4VSdEp%2FWOnZTCvdf4kOmBSq8paaIJSPNuC9vzwOtAZwHHlSyXtzMYNjDFRXRATV61wf8hn13MwLiQs%2BPdhIdfAuhPHoXaVqm0YtdGFmvW9nk%2Blam"
		"NHqiFCXCSVaahugk5eWUOsV0d4dphM0tLg3QA6CoZSMGiqE1C2ofxrzZV5Ur394hNcqgFhtgaFM%2BgSrNrJwOGLDYB3vz3mnR%2FEuMB5q8ca8%2B17ViZ0mu9N8ku68McvAOYUsPVu4xETknLQSMAg903lMyT8wWYO93wnpWghXp%2F%2FU79k0cATlpT5Kidw9Ns%2FxUyKgoKD6vyXhlgLuLfdNLOEAUA0IZVTY9PMMjzjZw0Kd0LVzFl7NG1FiDY9KtZ%2BrHqltKsMZcQaT%2BSpZdgdBDb7jhtFOMlcZfU1nHGsANUqiVudjY8w8%2BxqOoQVio8Avsn4v2ddjEb7C2rvVkRALo4e17TFPi4Yx2Ayo5TYfXepjPeWxE3ZTXMxxsULRbsA1zfNxoW9aqN73Skbr2rvV8JkJjo84Q6txvOQmWrwoIwDbh%2F8KP7d947uirTGQwxpqQqcDQVy%2Bdj0QanQ198vamJpjA4jFWEBXo1VBT7zrFFFc%2BMZfRAD7nRbWw9gZPqqkJEh4eYzwWLtAd0Gh5FNC6x4BFVQa7hd9o6Q53YCq2kU1oUk3ylCGLLGLquF90xAVyWLWXHlaif2ZsLHdShlnzzJ95JKKzO6R88ASgfqol%2Bi5T6Zwqq65xuwuJPHBLEjLErCtQ%3D%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B108%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtUserID=PTUser{pNumber}&txtPassword=etp%40123&txtConfirmPassword=etp%40123&txtFirstName=PTFName{pNumber}&txtLastName=PTLName{pNumber}&txtLevel1Usere=%5BEditValue%20is%20null%5D&cmbLanguage_VI=G"
		"B&cmbLanguage=English&cmbLanguage%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A225%3A1%3A501%3A74%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbLanguage%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbLanguage%24DDD%24L=GB&cmbSkin_VI=1&cmbSkin=Blue&cmbSkin%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbSkin%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbSkin%24DDD%24L=1&cmbUserType_VI=2&cmbUserType=Normal%20User&cmbUserType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A289%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbUserType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbUserType%24DDD%24L=2&txtEmailId=ptuser{pNumber}%40gmail.com&cmbCompany_VI=786&cmbCompany=ABC%20Ltd&cmbCompany%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A159%3A1%3"
		"A501%3A165%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbCompany%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbCompany%24DDD%24L=786&cmbDivision_VI=&cmbDivision=&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C5%3B786%7C0%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility_VI=&cmbFacility=&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C3%3B0%7C0%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&txtLocation=LOC&chkActive=C&chkLockStatus=U&pucUserOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%"
		"3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucUserRights%24ASPxSplitterLocation=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A100%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucUserRights%24ASPxSplitterLocation%24cbptrvUserRights%24trvUserRights=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN4%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN1%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3BC%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN4%26quot%3B%3A%26quot%3B2200%7C0%7C1%26quot%3B%2C%26quo"
		"t%3BN1%26quot%3B%3A%26quot%3B1200%7C0%7C1%26quot%3B%2C%26quot%3BN2%26quot%3B%3A%26quot%3B1400%7C0%7C1%26quot%3B%2C%26quot%3BN3%26quot%3B%3A%26quot%3B1800%7C0%7C1%26quot%3B%2C%26quot%3BN0%26quot%3B%3A%26quot%3B1000%7C0%7C1%26quot%3B%7D%5D%7D&pucUserRights%24chkCheckAllRights=I&pucDivisionFacilityRightsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A249%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3BTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTTT%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bb2Wj4rJwLIJOdCtgdPOsq3rl8H5F4th7t4TBsF3me%2FkevhP4z2FnqvlneFfY5Fm%2F2Huah3Wgih5S%2F%2Byw00orTrlLIXJ8XehllHtNrfIh%2FVHNmKIjg6sJkK%2FMhVsRHxY5YrFGVVw1OXYlerRGtTNFQovgODzMaJoDl4kllefH18o6DUYnlIATUydlDyTdptHYGdkHDj8UmwmDLTpXrYqrxzREzsj4AFw2zmAf32UdIRRjQ7yqPwlJNPjrbARY8Bf3rOH4j7zZPjqKCETpn4QHyrFtSCqtxI4JczS5CnWNrMEB82eayHtT%2B7c829Ne8nQf4gP0YWbyDo1mTTqGI7Vh6F5QZzvbjk"
		"RaFPlKDHXiaCKuf4zNWVUFfUm8crhPp4zfnaBgI70XYHpskuWidNqw1lz0KLjqi0SQAcsspEFTLZtJY7Gb65oRLX0%2FfSDol7criZLpgS3TLXrr%2BaOYKQRcLErN2E9%2FMAlwwgP8771wtJpZYwgZ62l8oeC1VI9hHPADGA7cS0EuTXXxm8iVxcrXbDZaX0bdzczGfDtx3dScoerrsmTpWaO%2Bk4CgwPvixKhOKQ2uU8C1RYl%2B8xjC5R6DrQpG1Rzt0Boj8aL26NTMI4LK4aQ5Sjn%2B%2B9PiuYsAxNdOdgG%2F6inUQOkZjTnWrxIS7FLfjo%2BU2kYdg7KNI6%2BpY3hiJ4fb%2FCxs3%2BM%2BkJqxJzh7infCaykFOM0Nu%2B%2FqkujiTusx%2FglLY1vFqODAfEqjke6n8Nx0xbhXDaGdi3qOAX8D%2B1aQL8khcdRxCRnqFQoK5YMv8iPUfOxkYDeDcil1mID%2FctwoOXjLZUZD7EyOh4nFsbuYzdLP%2FoBwQxFdIjIF%2FJ6zVWNe9F7Ziu8F8L%2BctMk86ifs6SSCsMdyJMxJgUIrfwqmA6iGGP4RtT3784uNn%2B6DNCHlpxVs9YmTxC0EIt1OEMsiNik4w%2B0FtKSKGaRROsg%2FvOVzmn0CRhKAS3UGW4Ewcd%2BwDbJyxegg%2FJdIHtblH7EPJ8%2FFJ9pTt6uAF%2F9LiVpZ7m18sC5xA5zT8UHhCx4JuQ86UHuMfPQy4w4Q0HrEYUkmrmcBYf%2FrxRH8LwRnjxWYc7Gcfj5ykiEdRlLkhiRQp0VH1wdRwiRfFcT1zYH6ESvrFQ5NqwEGK%2FBx%2FNwiYdg0XbHDJZsKb4ZzD68la7zMXThzEKR0QawAEc0qhBNhUoWc7nVRsMS49WD9nYN2f%2BXj0d48adKHshkSRQXkfNRNHFGSNdnqGtwvrp56%2FwuIdFQwEZCrr5OUAvfMJbEbl1TRyEInlXhjoHJvy2Vlkz4p7O"
		"MtBh3TEQL18C3wUWugHOS8wkdc5M%2BCj608RYTKSuspMXxOKP5mnfIWN3GKoHZ3cP279PATCb68A9Bhcmy%2FXx40efuFPp5AyPoyLJwYCbriE2wJzH3uD793QjIXnSDkN0ZHSR0d5ArAxHfE6FRqsWMKGL5zQZcMJhqrtGGp1zjZ5LTjvtQefSfsDFCVYj9Y5Bt7ihN9mLi5U2eKAUs1SzG7U9p7SkaXLDSZai9MxUJSGKghOep5NjfstRX%2BMWrsAoNOsKqddg1fyTpMgmd5tNnu2MsySDc2kZ9eCF%2FYYeEAGqYfFeraxgSB1ghN3t5Ls3jsp5kqG1S8MrcdFuIErjTxFsHihMNidTwIXUkzVYxT%2F%2Fg%2FJBIYJM%2B3G2uh7p%2FKWrabdpnCI95ennV9L7Knrk1KIVC4m36qg7Ugnbmm1cB5bnkTshlcf1a3700LC1NiaysY0w4zBfw%2FX68%2F0D%2BuqPRA0PTbzRJSl3cnLCb1yOPfzx3edW2De2iKzzMcDA6Ogb7DWuCizxgnH46zT%2FUwn3wMmRZRj9wq7Y2hTfcfekT%2Fk9EVs7fHpw0XlTZRxD1lTBPxyoJnklaUW%2FMvWgPDCBKmuU5pPYFVdsWhSayzf%2BSa8EgChASq2ZoIuMDKzcxfOxgoXSToSdq3Jj0uclEIqtWRk%2Bahkf6a0f1PncXkNyPWxZ5quG8hewfclm6mP46miXiMSxIcmUQzhFDED6XEATrTgSBq6Y%2B4DyRxZ4NcN%2B1rBcjxEeoH%2FgfSG5PQS5rcmH%2B4LAhTpLjqFa2pyGohn0kO1dHo5I5TgFjz%2FqAJJyP0EwfXfqIaW3YXzv5erS1QW%2BYjXw6Zcts2UX%2BiSTssMUO7xj0zPm2PTixm1wdeTXaLGZa6ilt01FUF3Hpes4TlupADbq9qVhfU8BBSk7HYCGCQizlcVMw1h%2Fbnew014yWVFBnUCGOX74hHrba0z9GN%2B8SL%2F0EGTb"
		"6ZM6QjrtXAtyhleqaKMqolHTmUOgyFIne6vx3RY5VySfj%2Fb9Uwphxa7RUzigvp0RlZBhdCrbW9zxNsOygG5uQnQ8sZVlNLpvb27aRjqgtk9klLJwdS263jjp%2Ft1JDoSq6b0RWJgY3%2FADRv%2FocOpDImKRMMj9PYjlruKChz%2BCbIodhN1zKBrBphmGfbpItrnE0HTJazxfNVw7zF1j6KtfdZrgVJDxs6r34%2FXf%2B74Wf98zDL%2BV%2FdZF9xgZDXRh4vB02q9cwGQId%2FwIo%2FT3TZmOFcy%2FtK4SN6ofHz3%2B0H4%2BvJxxqfiVAxihdVfTqyD2nblY9b39VqxwfemVAoqrIaEbLq4WKq3Uy9GNZ6bBMvhtI8oiH2i3y%2BBhFKpUceAP3RrvFM%2FJ7AGlhGy3GrlVItsnIUTlXWUbpCb56Gcjx2lkFHWZWxBOj4rvfSqoQQoJEQmc1hqvcD2rr7xCLjQkv7I1dRwuzySgqMgRwovjKDWPxy06BXQOtfkmOJ7freKLo60oxpgJIeWkxWIZp0PBhUk0aaGYMhKAf2INFIFS6Xks7H9TYGpfFZKiTkc%2FDp6RbzzfgETe9nWeaT1qtnydg6CNq%2Fsoiqk215FH1z7qVhrQgKolerZnvaLmpydng5lwD949IE3DkSPc7eMRXFhJaB9%2Bdf%2FwkG3l%2FnUkdN7ZJI%2F1Ni5sv0967BlTblrgMSAt%2Fo8yd0mHR4sYogx21i8oIXJ0Dl8M1XrFOrCAZEzAYEPG7LobCwY6xB85A4b%2BV%2FUEwqanzE7Q63muU%3D%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%7B%7D%26quot%3B%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3B402%26quot%3B%2C%26quot%3B202%26quot%3B%2C%26quot%3B103%26quot%3B%2C%26quo"
		"t%3B106%26quot%3B%2C%26quot%3B110%26quot%3B%2C%26quot%3B112%26quot%3B%2C%26quot%3B114%26quot%3B%2C%26quot%3B116%26quot%3B%2C%26quot%3B117%26quot%3B%2C%26quot%3B119%26quot%3B%2C%26quot%3B123%26quot%3B%2C%26quot%3B125%26quot%3B%2C%26quot%3B201%26quot%3B%2C%26quot%3B202%26quot%3B%2C%26quot%3B203%26quot%3B%2C%26quot%3B204%26quot%3B%2C%26quot%3B205%26quot%3B%2C%26quot%3B206%26quot%3B%2C%26quot%3B207%26quot%3B%2C%26quot%3B208%26quot%3B%2C%26quot%3B323%26quot%3B%2C%26quot%3B33%26quot%3B%2C%26quot%3B34%26quot%3B%2C%26quot%3B435%26quot%3B%2C%26quot%3B440%26quot%3B%2C%26quot%3B456%26quot%3B%2C%26quot%3B601%26quot%3B%2C%26quot%3B603%26quot%3B%2C%26quot%3BDEF%26quot%3B%2C%26quot%3B501%26quot%3B%2C%26quot%3BDEF%26quot%3B%2C%26quot%3B525%26quot%3B%2C%26quot%3B625%26quot%3B%2C%26quot%3B725%26quot%3B%5D%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%"
		"24DXFREditorcol1=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol2=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol3=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFREditorcol4=&pucDivisionFacilityRights%24grvDivisionFacilityRights%24custwindowState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXHFPState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionFacilityRights%24grvDivisionFacilityRights%24DXFilterRowMenu=%7B%26quot%3BselectedItemIndexPath%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcheckedState%26quot%3B%3A%26quot%3B%26quot%3B%7D&pucEmailAlertsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1"
		"%3A432%3A207%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDeleteConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A48%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26"
		"quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24ASPxPanel2%24grvLocationHierarchy=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B5PCvQ15EHRFKAZUigXHlVXW6bI8MMvPIHhr1DBEvE%2FXcQf%2FuHsiucqDtY5Dt6OhruDP4zLbD2D0fY2NLaz08uXHm4H0dm2lrr0Xbtxpp%2BKdi%2B%2BrxJS8ddWoh%2FRDQz7dHxXo4I6N43HS0cIjB2kukBdeMGV4pnpKmasYsNQA66TXKuMOTZcbSRceCMze4h%2BZvjh9SDvfNEV0nL0Ro4v6P0s8PMK3sV4gjL3B%2FST0cS38MflQdZVJJrDs8AutChwVMfI%2BrkpaD7i3SXMGtKYY92lE%2BRLj31cyQY80O3C7p%2BuW1Oav6FhlaHZMbVV%2FkSO4zx4e1CZRonrUXjGy1F2lJFBDgh4OXc4Nk%2FuncLs2iODWR754wdMKmfC9OJQxxWWzMEkW7s%2FXrAxvIw80uM66d93b9ZfaiqkRg%2FBBAi6S6H9C4C6dg8Fl5%2BP1fv9uH2v2nWtjnGyialZsymt7AC2oUrU%2FSI8wnWZTzuh5Eyys9lbc%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%"
		"2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ASPxPanel1%24splStrategyLocationHierarchy%24chbSelectAll=I&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_277%2C1_198%2C1_209%2C1_217%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_201%2C1_297%2C1_302%2C1_261%2C1_258%2C1_257%2C1_235%2C1_248%2C1_242%2C1_251%2C1_250%2C1_249%2C1_245%2C1_241%2C1_239%2C1_247%2C1_296%2C1_279%2C1_289%2C1_216&DXCss=V6UI%2Ffont-awesome.min.css%2C1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css&__CALLBACKID=cbpSaveDivisionFacilityRights&__CALLBACKPARAM=c0%3A",
		"EXTRARES",
		"URL=http://192.168.1.106:8008/ssdp/device-desc.xml", "ENDITEM",
		"LAST");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_url("desc", 
		"URL=http://192.168.1.106:45371/upnp/dev/689be3e6-205e-4e7a-8f40-f6032d6a2840/desc", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t160.inf", 
		"Mode=HTML", 
		"LAST");

 

	if (atoi(lr_eval_string("{RecordCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_09_SaveAgain",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_09_SaveAgain",1);
        return(0);
         }
	
	
	lr_think_time(2);
	
	lr_start_transaction("ETP_NormalUserCreation_10_Logout");

	web_add_auto_header("Origin", 
		"http://172.24.1.129");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("LogOut.aspx", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/LogOut.aspx", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx", 
		"Snapshot=t161.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"SaveCount=LogOutCount",
		"Text=Division",
		"LAST");

	web_submit_data("HomePage.aspx",
		"Action=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx",
		"Snapshot=t162.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=ctl00_tsmMaster_HiddenField", "Value=", "ENDITEM",
		"Name=__EVENTTARGET", "Value=", "ENDITEM",
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM",
		"Name=__VIEWSTATE", "Value={CorrelationParameter_2}", "ENDITEM",
		"Name=__VIEWSTATEGENERATOR", "Value=2C7D260F", "ENDITEM",
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM",
		"Name=ctl00$hdfPageNameForTab", "Value=", "ENDITEM",
		"Name=ctl00$hdnLogout", "Value=Are you sure you want to logout ?", "ENDITEM",
		"Name=ctl00$MainContent$pgcTabs", "Value={&quot;activeTabIndex&quot;:5}", "ENDITEM",
		"Name=ctl00$MainContent$pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=ctl00$MainContent$hdnBRClose", "Value=", "ENDITEM",
		"Name=ctl00$MainContent$pucConfirmCBMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=ctl00$pucConfirmMessageState", "Value={&quot;windowsState&quot;:&quot;1:1:12000:509:264:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=ctl00$pucConfirmMessage$ASPxPanel4$btnConfirmYes", "Value=Yes", "ENDITEM",
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_296,1_299,1_288,1_209,1_216,1_198", "ENDITEM",
		"Name=DXCss", "Value=1_50,1_51,1_16,1_13,1_40,1_4,1_14,V6UI/font-awesome.min.css,https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css,Styles/Master.css,Images/Icons/ETP_icon.ico,Styles/Common.css,SideMenu/css/demo.css?v=1.1,Font/fonts.css,V6UI/css/aaddbb1.min.css?v=1.1,V6UI/css/aaddbb.min.css?v=1.1,V6UI/css/_all-skins.min.css?v=1.1,V6UI/css/common.css?v=1.1,Styles/loadingPanel.css", "ENDITEM",
		"LAST");

 

	if (atoi(lr_eval_string("{LogOutCount}")) > 0){
        lr_end_transaction("ETP_NormalUserCreation_10_Logout",0);
        }
    else{
        lr_end_transaction("ETP_NormalUserCreation_10_Logout",1);
        return(0);
         }
	
	return 0;
}
# 5 "d:\\etp\\scripts\\etp_normalusercreation\\\\combined_ETP_NormalUserCreation.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 6 "d:\\etp\\scripts\\etp_normalusercreation\\\\combined_ETP_NormalUserCreation.c" 2

