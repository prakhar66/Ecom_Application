# 1 "d:\\project\\etp\\etp scripts\\campaignnewedit\\\\combined_CampaignNewEdit.c"
# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


# 1075 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_search_row(PVCI pvci, char * columnNames, char * messages, char * delimiter, char * **outcolumns, char * **outvalues);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);
VTCERR   vtc_update_all_message_ifequals(PVCI pvci, char * columnNames, char * message, char * ifmessage, char * delimiter, unsigned short *outRc);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_search_row(char * columnNames, char * messages, char * delimiter);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);
VTCERR   lrvtc_update_all_message_ifequals(char * columnNames, char * message, char * ifmessage, char * delimiter);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "d:\\project\\etp\\etp scripts\\campaignnewedit\\\\combined_CampaignNewEdit.c" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_search_row(PVCI2 pvci, char *columnNames, char *messages, char *delimiter, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_search_row(char *columnNames, char *messages, char *delimiter);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "d:\\project\\etp\\etp scripts\\campaignnewedit\\\\combined_CampaignNewEdit.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrw_custom_body.h" 1
 





# 8 "globals.h" 2

# 1 "AsyncCallbacks.c" 1
 
 
 
int Poll_0_RequestCB()
{
	 

	 
	 

	 
	 
	 

	return WEB_ASYNC_CB_RC_OK;
}

int Poll_0_ResponseCB(
	const char *	aResponseHeadersStr,
	int				aResponseHeadersLen,
	const char *	aResponseBodyStr,
	int				aResponseBodyLen,
	int				aHttpStatusCode)
{
	 

	 
	 

	return WEB_ASYNC_CB_RC_OK;
}

# 9 "globals.h" 2




 
 




# 3 "d:\\project\\etp\\etp scripts\\campaignnewedit\\\\combined_CampaignNewEdit.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 4 "d:\\project\\etp\\etp scripts\\campaignnewedit\\\\combined_CampaignNewEdit.c" 2

# 1 "Action.c" 1
Action()
{

	lr_start_transaction("Launch");

	web_set_sockets_option("SSL_VERSION", "AUTO");

	web_set_max_html_param_len("52056");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/UserLogin.aspx*",
		"LAST");

	web_url("UserLogin.aspx", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t60.inf", 
		"Mode=HTML", 
		"LAST");

	web_convert_param("CorrelationParameter_URL2",
		"SourceString={CorrelationParameter}",
		"SourceEncoding=HTML",
		"TargetEncoding=URL",
		"LAST");

	lr_end_transaction("Launch",2);

	lr_start_transaction("Login");

	web_add_auto_header("Origin", 
		"http://172.24.1.129");

	lr_think_time(17);

 
# 65 "Action.c"
	web_reg_async_attributes("ID=Poll_0", 
		"Pattern=Poll", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx", 
		"PollIntervalMs=5400", 
		"RequestCB=Poll_0_RequestCB", 
		"ResponseCB=Poll_0_ResponseCB", 
		"LAST");

	web_custom_request("UserLogin.aspx_2",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx",
		"Snapshot=t61.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_URL2}&__VIEWSTATEGENERATOR=286ECC0B&__VIEWSTATEENCRYPTED=&txtUserName%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3BAdmin%26quot%3B%7D&txtUserName=Admin&txtPassword%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&txtPassword=&cmbDivision%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbDivision_VI=&cmbDivision=Division&cmbDivision%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbDivision%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3BLECC%7C0%3B%3B%26quot%3B%7D&cmbDivision%24DDD%24L=&cmbFacility%24State=%7B%26quot%3BrawValue%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbFacility_VI=&cmbFacility=Operating%20Unit&cmbFacility%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbFacility%24DDD%24L%24State=%7B%26quot%3BCustomCa"
		"llback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbFacility%24DDD%24L=&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageWarningMsgCubeState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucConfirmMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucVersionInfoState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucVersionInfo%24ASPxPanel1%24aspxVersionMemo=Product%20version%3A%20V5.5%20R10%0A%0ARelease%20Date%3A%2031-10-2018%0A%0ABuild%20No%3A%201.0%0A%0ABuild%20Date%3A%2031-10-2018&pucChangePasswordState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucPasswordChangeState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A"
		"-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucDivisionCheckState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_209%2C1_217%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_216%2C1_198&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_17%2C1_14%2C1_16%2C1_13%2CImages%2FIcons%2FETP_icon.ico%2CStyles%2FUserLogin.css%2CStyles%2FMaster.css%2CStyles%2FCommon.css%2CFont%2Ffonts.css%2CStyles%2FBusinessRule.css%2CStyles%2FLogin_style.css%2CStyles%2FloadingPanel.css&__CALLBACKID=cmbDivision&__CALLBACKPARAM=c0%3ALECC%7C0%3B%3BLBCRI%7C4%3B0%3A-2%3B",
		"LAST");

	lr_think_time(5);

 


	 
# 109 "Action.c"

	web_add_auto_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(5);

 


	 
# 169 "Action.c"

 


	web_stop_async("ID=Poll_0", 
		"LAST");

	 

 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter_1",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"IgnoreRedirections=Yes",
		"RequestUrl=*/HomePage.aspx*",
		"LAST");

	web_submit_data("UserLogin.aspx_5", 
		"Action=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx", 
		"Method=POST", 
		"RecContentType=text/html", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/UserLogin.aspx", 
		"Snapshot=t64.inf", 
		"Mode=HTML", 
		"EncodeAtSign=YES", 
		"ITEMDATA", 
		"Name=__EVENTTARGET", "Value=", "ENDITEM", 
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM", 
		"Name=__VIEWSTATE", "Value=4X3EDENCSnBwmK8jRxMi9OHZoonXsnncyU2EKez0EY8nShOUdsDHgfJkZO8QZoEu+NFZswJSoEf7t3lUCAKTeV8iNtL/uEM7YwPauigiX+2BYVYhopGwjI7K8aag7k7eg2R3DQrGNxg2nMyv3cU1PJTiXOxFaoC4RQo/rNWe8gOGBEL2ep6Ei0q3YgI1MO70jAUbKJpsv8GAFNO1uEcepB25IZ/qCKzfl5DFtAzSr2irtFY645P4h8V6MFOmapNhDouhi5BSpylKe5XyMn+BlL/dSArXK1z6y3mJhgh+WCDQgjUmh5Yq4ugJfozoekoV8kpYr6Ej3ROlpsQe/ItuErhHKm1eg/+vLhFRGIZWSbxfqPkDiYDXGFHd0t3MTsWpLcYinD06cbQwWI2Smle8sccTgeHKCkic2J19baYTGu5o5qfMBQbg+GDgspaqt4l6xVYq5D+"
		"s3PpwUHgAnWTFwZ87f02CPiwscZ6+NAqjLC9KHLB6ueAzBoG4/8WGaENVPx4/kZYkGu4AnpwEuWitU25A9FQtSLzx5t/tf+WsKYrirp8pvJL6HNV8DRyy2rtBqvvUKD3CstXRVNnYg1p7Rp8LE0sP8QYTcKxpYyJ+C9WoL5P+Hn2W6A34f5IjcBbrNxclSzm3XQDsbIHOsHXjhp7Y6onwKNbfkY4L+wz/t7SUAB5ifAQFz76QZfA8VxXJH7FUXFhO8surXUrV7J95Wyk3KFoMPcoKLZFiejn22hiJdnNv6SOAS8oPypWBAMmjj6uRDc/ZoF+0bGLBreYEiJ7EEtWRPPft5/Q4psuptR7TA55gFur+qhEz/Q8skoYo4gqg7Uy7NswokmplFOQPoJD+t+pQyOnR1Kr3gK2Uh+DWuatoUxIjuM5s0NY5F3mOcQvONNN8uN6t770F69cluU7KWtLAFcRybgIdCq/"
		"vqQdtfgZlGu53AmwbcPk3WZ2i7blq8KyXGATN/Rjb0tArv/RFYuKvUTwLaLnt9kKWS4ry3ttfh0uDgl4Fw+R+uGARglGunyfWBnTR7NIjQ4d0d4X6/VIajCV3NWLwJRQVeP7+qe142iCGgE35wsfl9wvcRLEmJdrQSLIb/ZB+ieigDgktnbmp7yrAydSwb5TexDeyvBzj4/Cm9qTgvuN7ypu2NwtMrnD7yrWo7qs3+hZLmpqSwrex28ni6A6rBFojuWzTkrDoAVSAsEMtCgCrKx9hGOY/15qNmm/opCBoz8vSWAvk3DOey3BsOoyXFqB7A3u3odBuKtVCPGh/u92BKYk5qupsB6VO7boTmMBvoS4ZrWW8lkHN9dxX5dwAFAHOkKiukbZ6vdMjSOEir50gPZQRw9iKuK5w7ffmzmEcRIHIQ5iHFTxPny6kuCKUZKGyqvnja1E3AMHQh9QCJqBHP1IlhECdFzUvJOkHFFYRGh/"
		"wwfyKpQe5MO2aKn6cupxFeATnPD4aoYKfh5qTucZi5bGaexiagLEZjJy5JRC4hFDMsUFb3PgWAAJVsV/PKlUKDqrkQwCXe+FAdk6+S8eJGSLFReH/W4tk6DN6SOtKOIg50EIEN3u8WgWdvXp3gZWVc2v6hzsaD9aYzudlU8uP+EfrkVAeGcX50wwH50Vyot7eYck0kdxBeN27V8JnWXqrTMP05Md3sZFpacgTO0qH+oPVkNWQZfx+h2JJUtrba/FxCr7NUayW950igzO/AgkMPjWdEm7zGAiBlwCPnYZtebnZSw2N0UtvZHlAxeCKYEit+sfTGZ0tDcGiUKKc9Eso6AP3hhJA6pHzt3o6ik/0vhz1FU84if5JSjRGoUgMcaSULTqfSr+54ZIXIJ80JmapHdvhBrlKYhpgrkcLe/v8qFBEm66cdnrax4XGBKOdw4YOlblyqdrvBEfaLdBOoEeNM4t9u85/"
		"CPzrbaV8Ce4PUfKyrBqGnSjaqv1+scOLR9hHLE9Fn8Hjz3XziFfP5Rwel4UkNShvbORAQLcUzJXzjTpPoHu//k0IFa4hzqsQ7lbPexK5qilOVkJDz7Ia/tBDKjqrOiOEmg8DiQddzt+5/Ibo3Jn9zWAQCsfVTajjNPq81QCg3Kfj/mnr9mVlkFzSUtehPZ9UZIj5SSBQ5fzegKj0QlYB9JbFHsF4G4w8uZK3VmGEzQ4eiMcV1Ph4ExYisVbIGhSFA5EQfjN3PougJBtWQWFJq2TMjTI4nTa4XhPHobUJmRkn+EWVRCpevDY0IaW9tA5kjSRpSYpTJzqF9H03NCHZ1Y3nC4o2AtTP6ALqKg==", "ENDITEM", 
		"Name=__VIEWSTATEGENERATOR", "Value=286ECC0B", "ENDITEM", 
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM", 
		"Name=txtUserName$State", "Value={&quot;rawValue&quot;:&quot;Admin&quot;}", "ENDITEM", 
		"Name=txtUserName", "Value=Admin", "ENDITEM", 
		"Name=txtPassword$State", "Value={&quot;rawValue&quot;:&quot;etp@123&quot;}", "ENDITEM", 
		"Name=txtPassword", "Value=etp@123", "ENDITEM", 
		"Name=cmbDivision$State", "Value={&quot;rawValue&quot;:&quot;India Retail(888)&quot;}", "ENDITEM", 
		"Name=cmbDivision_VI", "Value=888", "ENDITEM", 
		"Name=cmbDivision", "Value=India Retail(888)", "ENDITEM", 
		"Name=cmbDivision$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=cmbDivision$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;LECC|0;;&quot;}", "ENDITEM", 
		"Name=cmbDivision$DDD$L", "Value=888", "ENDITEM", 
		"Name=cmbFacility$State", "Value={&quot;rawValue&quot;:&quot;Retail Unit(202)&quot;}", "ENDITEM", 
		"Name=cmbFacility_VI", "Value=202", "ENDITEM", 
		"Name=cmbFacility", "Value=Retail Unit(202)", "ENDITEM", 
		"Name=cmbFacility$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=cmbFacility$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;LECC|3;888;&quot;}", "ENDITEM", 
		"Name=cmbFacility$DDD$L", "Value=202", "ENDITEM", 
		"Name=pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=pucMessageWarningMsgCubeState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=pucConfirmMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:508:261:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=pucConfirmMessage$ASPxPanel4$btnConfirmYes", "Value=Yes", "ENDITEM", 
		"Name=pucVersionInfoState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=pucVersionInfo$ASPxPanel1$aspxVersionMemo", "Value=Product version: V5.5 R10\r\n\r\nRelease Date: 31-10-2018\r\n\r\nBuild No: 1.0\r\n\r\nBuild Date: 31-10-2018", "ENDITEM", 
		"Name=pucChangePasswordState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=pucPasswordChangeState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=pucDivisionCheckState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM", 
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_209,1_217,1_190,1_223,1_208,1_206,1_288,1_212,1_216,1_198", "ENDITEM", 
		"Name=DXCss", "Value=1_40,1_50,1_51,1_4,1_17,1_14,1_16,1_13,Images/Icons/ETP_icon.ico,Styles/UserLogin.css,Styles/Master.css,Styles/Common.css,Font/fonts.css,Styles/BusinessRule.css,Styles/Login_style.css,Styles/loadingPanel.css", "ENDITEM", 
		"LAST");
		
 
 
 
 

	

	lr_end_transaction("Login",2);

	lr_start_transaction("Create new campaign");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	lr_think_time(15);
	
	web_reg_save_param_regexp(
		"ParamName=pCampaignID",
		"RegExp=\"hdfMaxStrategyId\" id=\"hdfMaxStrategyId\" value=\"([0-9]+)\"",
		"SEARCH_FILTERS",
		"LAST");

 





	web_reg_save_param_regexp(
		"ParamName=CorrelationParameter_2",
		"RegExp=id=\"__VIEWSTATE\" value=\"([0-9,A-Z,+,/,a-z,=]+)\"",
		"Ordinal=1",
		"SEARCH_FILTERS",
		"Scope=Body",
		"RequestUrl=*/Strategy.aspx*",
		"LAST");
		
	web_reg_find("Fail=NotFound",
		"SaveCount=SaveCount",
		"Text=Save",
		"LAST");

	

	web_url("Strategy.aspx", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx", 
		"Snapshot=t65.inf", 
		"Mode=HTML", 
		"LAST");

	web_convert_param("CorrelationParameter_2_URL2",
		"SourceString={CorrelationParameter_2}",
		"SourceEncoding=HTML",
		"TargetEncoding=URL",
		"LAST");

	(web_remove_auto_header("Upgrade-Insecure-Requests", "ImplicitGen=Yes", "LAST"));

	web_add_auto_header("Origin", 
		"http://172.24.1.129");


	
	
	web_custom_request("Strategy.aspx_2",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t66.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=&hdftxtStrategyId=&hdnerror=&hdnname=&hdnDescription=&hdnId=&hdnSales=&hdnImageName=&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=&hdnMonitorLevel=&hdnStatus=&hdfSelectedHierarchy=&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26qu"
		"ot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0pj0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl"
		"28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyID=&txtStrategyName=&txtStrategyDescription=&cmbStatus_VI=&cmbStatus=&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=&cmbMonitorType_VI=&cmbMonitorType=&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=&cmbMonitorLevel_VI=&cmbMonitorLevel=&cmb"
		"MonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=&txtSales=&txtLocation=&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bs"
		"t%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bi0j8lqCQQUF%2FQQlSS4D1mP%2FHBy5w3H4hajr1e4%2B1mo57Btu3YFdHAlpAz0ChXzI4IfEyPzfu2MXc2Z9oPrRkEc81z7Mt7%2BClW9olONVI"
		"iFwJ7u7lyLpTW5ZTV1mwfC3xDkeW3RgvQlGHVXgGlmcjJw80Uqq7kJNBzOd0EpCRKpIJLV%2BSuVRpnpcVNOaKy67P73YEomtB9qq3YdNxfhJVoO1sKVGPLYTU2cGhGdUfa21s5z3G45nuSCc7jSdQCqe2tmylV9s%2BVIVKuwuKjdHNy1SBa8P67DmN2G0CYKQqwjG4ohqc%2Fd%2Fu1iJAkD9rHItjryAFMKArnTGLjdeNUwwG2m3ZC%2Bx1GZBiXgXiJGqNVBpjx0Ipj7PlDzwWMq1hXelI5vBz6JOZnAj%2BSg49iXcXZc1mmfRlBcRdWYMiDmvo8nyhLQ0HXL2yuCp92ir1yVBrIRdICwzeVCjy%2BdD0mdtY28wPNrPOSNKee7ecJCbmbOcnNRY2EFmz5%2BhTa4IC5x23j6i9O6P96I5VXe46forVxw%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetS"
		"ales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState"
		"%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=cbptrlStrategy%24trlStrategy&__CALLBACKPARAM=c0%3A4%20999-888-202-114-0-1-2-0",
		"EXTRARES",
		"URL=Images/StrategyImages/sample05-10-2022_163724.jpg", "ENDITEM",
		"LAST");

	 

	lr_think_time(5);



	
	web_custom_request("Strategy.aspx_3",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t67.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId=114&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=0&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%26quot%3B%3A%26quot%3B%26quot%3B%2C%2"
		"6quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0pj0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOs"
		"OwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyID=114&txtStrategyName=PTTest11&txtStrategyDescription=PerfTest11&cmbStatus_VI=0&cmbStatus=Inactive&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=0&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorType%24DDD%24L%24State=%7B%26quo"
		"t%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=%2C%20LOCANZ&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3"
		"A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BU%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3B"
		"callbackState%26quot%3B%3A%26quot%3Bi0j8lqCQQUF%2FQQlSS4D1mP%2FHBy5w3H4hajr1e4%2B1mo57Btu3YFdHAlpAz0ChXzI4IfEyPzfu2MXc2Z9oPrRkEc81z7Mt7%2BClW9olONVIiFwJ7u7lyLpTW5ZTV1mwfC3xDkeW3RgvQlGHVXgGlmcjJw80Uqq7kJNBzOd0EpCRKpIJLV%2BSuVRpnpcVNOaKy67P73YEomtB9qq3YdNxfhJVoO1sKVGPLYTU2cGhGdUfa21s5z3G45nuSCc7jSdQCqe2tmylV9s%2BVIVKuwuKjdHNy1SBa8P67DmN2G0CYKQqwjG4ohqc%2Fd%2Fu1iJAkD9rHItjryAFMKArnTGLjdeNUwwG2m3ZC%2Bx1GZBiXgXiJGqNVBpjx0Ipj7PlDzwWMq1hXelI5vBz6JOZnAj%2BSg49iXcXZc1mmfRlBcRdWYMiDmvo8nyhLQ0HXL2yuCp92ir1yVBrIRdICwzeVCjy%2BdD0mdtY28wPNrPOSNKee7ecJCbmbOcnNRY2EFmz5%2BhTa4IC5x23j6i9O6P96I5VXe46forVxw%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3B"
		"windowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2h"
		"nMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=cbpNewStrategyTab&__CALLBACKPARAM=c0%3A",
		"LAST");

	web_submit_data("Strategy.aspx_4",
		"Action=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t68.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=__EVENTTARGET", "Value=", "ENDITEM",
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM",
		"Name=__VIEWSTATE", "Value={CorrelationParameter_2}", "ENDITEM",
		"Name=__VIEWSTATEGENERATOR", "Value=9ABF3D45", "ENDITEM",
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM",
		"Name=hdfClickedbutton", "Value=New", "ENDITEM",
		"Name=hdfMaxStrategyId", "Value=115", "ENDITEM",
		"Name=hdfCheckFromListBox", "Value=", "ENDITEM",
		"Name=hdfIsExists", "Value=", "ENDITEM",
		"Name=hdfStrategyId", "Value=999-888-202-114-0-1-2-0", "ENDITEM",
		"Name=hdftxtStrategyId", "Value=115", "ENDITEM",
		"Name=hdnerror", "Value=", "ENDITEM",
		"Name=hdnname", "Value=PTTest11", "ENDITEM",
		"Name=hdnDescription", "Value=PerfTest11", "ENDITEM",
		"Name=hdnId", "Value=", "ENDITEM",
		"Name=hdnSales", "Value=350000", "ENDITEM",
		"Name=hdnImageName", "Value=sample05-10-2022_163724.jpg", "ENDITEM",
		"Name=hdnTBNew", "Value=1", "ENDITEM",
		"Name=hdnTBEdit", "Value=1", "ENDITEM",
		"Name=hdnTBDelete", "Value=1", "ENDITEM",
		"Name=hdnTBBusinessRule", "Value=1", "ENDITEM",
		"Name=hdnTBRefresh", "Value=1", "ENDITEM",
		"Name=hdnTBRefreshLocations", "Value=1", "ENDITEM",
		"Name=hdnMonitorType", "Value=0", "ENDITEM",
		"Name=hdnMonitorLevel", "Value=1", "ENDITEM",
		"Name=hdnStatus", "Value=0", "ENDITEM",
		"Name=hdfSelectedHierarchy", "Value=", "ENDITEM",
		"Name=hdnAttachedBR", "Value=", "ENDITEM",
		"Name=hdfSelectedIndexUnselectedBR", "Value=", "ENDITEM",
		"Name=hdfActivateBR", "Value=", "ENDITEM",
		"Name=hdfDeactivateBR", "Value=", "ENDITEM",
		"Name=hdfpucTargetsale", "Value=", "ENDITEM",
		"Name=hdfMonitorCriteriaExist", "Value=", "ENDITEM",
		"Name=hdfMonitorCriteriaExistOnRemoveAttachBR", "Value=", "ENDITEM",
		"Name=hdfIsMonitorCriteriadelete", "Value=", "ENDITEM",
		"Name=hdfSavePreviosStatus", "Value=", "ENDITEM",
		"Name=hdnPreviousId", "Value=", "ENDITEM",
		"Name=hdfExpanded", "Value=", "ENDITEM",
		"Name=hdfNodeEditingFlag", "Value=", "ENDITEM",
		"Name=hdfRemoved", "Value=", "ENDITEM",
		"Name=hdfDuplicateValue", "Value=", "ENDITEM",
		"Name=hdfHierarchySelectedNodeName", "Value=", "ENDITEM",
		"Name=hdfHierarchySelectedNodeText", "Value=", "ENDITEM",
		"Name=hdfDeleteByIdOnUncheck", "Value=", "ENDITEM",
		"Name=txtSearch", "Value=", "ENDITEM",
		"Name=cbptrlStrategy$trlStrategy", "Value={&quot;editorValues&quot;:&quot;&quot;,&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;7/taFsY5gtg3vt2AX9zl/CiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2/ZFhMlRsr/ucVR0alPJl5xmyDpj/f7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM+v20sSAvpYAJfs+VN9L+lgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs/XXfLgZJ/9ICUIcsYmKNTY/96g4zl/3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U+wqAaOf8/6SVc7II7Lk0lVSryJW5XwF9/cDQJ78XqtytNbFuMVNuKL+awWInU7k2FumE15rJRiS42kjANt0P1/6397anJ1qCIiT/LIltKuq33ivr/YQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0/7palXOofceNskD/UxS1i+IotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV+UxBjY5Ur8gj8R78UWMB8yEx9XN/uYRVZwxxb+shi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH/bS7zq+tUXn5IAgWCYRgS8Efw3f3/RbVuG2cVsUqorWOb1sWxSSA/rB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs/569KcB+PZImBxq3GWuQFe96d55O0pj0685s6GZ8FiE+aR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGR"
		"DpQri+QOX7WEXpc78vPL68A9wSl28pHxy+B5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz/e2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs/eUBL/vq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59&quot;,&quot;focusedKey&quot;:&quot;999-888-202-114-0-1-2-0&quot;,&quot;resizingState&quot;:&quot;&quot;,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=txtStrategyID", "Value=115", "ENDITEM",
		"Name=txtStrategyName", "Value={pName}", "ENDITEM",
		"Name=txtStrategyDescription", "Value={pName}", "ENDITEM",
		"Name=cmbStatus_VI", "Value=1", "ENDITEM",
		"Name=cmbStatus", "Value=Active", "ENDITEM",
		"Name=cmbStatus$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:168:1:501:96:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbStatus$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbStatus$DDD$L", "Value=1", "ENDITEM",
		"Name=cmbMonitorType_VI", "Value=1", "ENDITEM",
		"Name=cmbMonitorType", "Value=Campaign", "ENDITEM",
		"Name=cmbMonitorType$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:200:1:501:50:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbMonitorType$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbMonitorType$DDD$L", "Value=1", "ENDITEM",
		"Name=cmbMonitorLevel_VI", "Value=2", "ENDITEM",
		"Name=cmbMonitorLevel", "Value=Amount", "ENDITEM",
		"Name=cmbMonitorLevel$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:232:1:501:50:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbMonitorLevel$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbMonitorLevel$DDD$L", "Value=2", "ENDITEM",
		"Name=txtSales", "Value=350000", "ENDITEM",
		"Name=txtLocation", "Value=", "ENDITEM",
		"Name=ucStrategy", "Value={&quot;inputCount&quot;:1}", "ENDITEM",
		"Name=pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucMessageOnDeleteState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucShowBRState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucLocHierarchyState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy", "Value={&quot;state&quot;:[{&quot;s&quot;:50,&quot;st&quot;:&quot;%&quot;,&quot;c&quot;:0,&quot;spt&quot;:0,&quot;spl&quot;:0},{&quot;s&quot;:50,&quot;st&quot;:&quot;%&quot;,&quot;c&quot;:0,&quot;spt&quot;:0,&quot;spl&quot;:0}]}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$txtSearchtrvHierarchy", "Value=", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$cbptrvHierarchy$trvHierarchy", "Value={&quot;nodesState&quot;:[{&quot;N0&quot;:&quot;&quot;},&quot;&quot;,{&quot;N0&quot;:&quot;U&quot;},{&quot;N0&quot;:&quot;LOC|1|N|&quot;}]}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$ctl07$grvLocationHierarchy", "Value={&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;i0j8lqCQQUF/QQlSS4D1mP/HBy5w3H4hajr1e4+1mo57Btu3YFdHAlpAz0ChXzI4IfEyPzfu2MXc2Z9oPrRkEc81z7Mt7+ClW9olONVIiFwJ7u7lyLpTW5ZTV1mwfC3xDkeW3RgvQlGHVXgGlmcjJw80Uqq7kJNBzOd0EpCRKpIJLV+SuVRpnpcVNOaKy67P73YEomtB9qq3YdNxfhJVoO1sKVGPLYTU2cGhGdUfa21s5z3G45nuSCc7jSdQCqe2tmylV9s+VIVKuwuKjdHNy1SBa8P67DmN2G0CYKQqwjG4ohqc/d/u1iJAkD9rHItjryAFMKArnTGLjdeNUwwG2m3ZC+x1GZBiXgXiJGqNVBpjx0Ipj7PlDzwWMq1hXelI5vBz6JOZnAj+Sg49iXcXZc1mmfRlBcRdWYMiDmvo8nyhLQ0HXL2yuCp92ir1yVBrIRdICwzeVCjy+dD0mdtY28wPNrPOSNKee7ecJCbmbOcnNRY2EFmz5+hTa4IC5x23j6i9O6P96I5VXe46forVxw==&quot;,&quot;groupLevelState&quot;:{},&quot;keys&quot;:[],&quot;focusedRow&quot;:-1,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$chbSelectAll", "Value=I", "ENDITEM",
		"Name=pucStrategyOperationsState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucTargetSalesState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucTargetSales$ASPxPanel6$txtpucTargetSales", "Value=", "ENDITEM",
		"Name=pucStartegyPrintState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucStartegyPrint$ASPxPanel8$grvStrategyPrint", "Value={&quot;focusedRow&quot;:-1,&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;n1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez/A5M+Ill/svc8VYzXj/DbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha+XrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY=&quot;,&quot;groupLevelState&quot;:{},&quot;keys&quot;:[],&quot;scrollState&quot;:null,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=pucMonitorCriteriaValidationState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_198,1_209,1_217,1_277,1_196,1_254,6_19,1_262,6_17,1_260,6_14,1_263,6_18,1_256,1_244,6_15,1_216,1_190,1_223,1_208,1_206,1_288,1_212,1_303,1_297,1_302,1_235,1_248,1_242,1_251,1_239,1_247,1_201,1_261,1_258,1_250,1_249", "ENDITEM",
		"Name=DXCss", "Value=1_40,1_50,1_51,1_4,1_16,1_17,1_14,1_13,6_1,6_3,6_0,1_22,1_21,Styles/Strategy.css,Styles/Common.css,Styles/Master.css,Styles/BusinessRule.css,Font/fonts.css,V6UI/font-awesome.min.css", "ENDITEM",
		"Name=__CALLBACKID", "Value=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$ctl07$grvLocationHierarchy", "ENDITEM",
		"Name=__CALLBACKPARAM", "Value=c0:KV|2;[];FR|2;-1;GB|19;14|CUSTOMCALLBACK0|;", "ENDITEM",
		"LAST");

	web_submit_data("Strategy.aspx_5",
		"Action=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t69.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=__EVENTTARGET", "Value=", "ENDITEM",
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM",
		"Name=__VIEWSTATE", "Value={CorrelationParameter_2}", "ENDITEM",
		"Name=__VIEWSTATEGENERATOR", "Value=9ABF3D45", "ENDITEM",
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM",
		"Name=hdfClickedbutton", "Value=New", "ENDITEM",
		"Name=hdfMaxStrategyId", "Value=115", "ENDITEM",
		"Name=hdfCheckFromListBox", "Value=", "ENDITEM",
		"Name=hdfIsExists", "Value=", "ENDITEM",
		"Name=hdfStrategyId", "Value=999-888-202-114-0-1-2-0", "ENDITEM",
		"Name=hdftxtStrategyId", "Value=115", "ENDITEM",
		"Name=hdnerror", "Value=", "ENDITEM",
		"Name=hdnname", "Value=PTTest11", "ENDITEM",
		"Name=hdnDescription", "Value=PerfTest11", "ENDITEM",
		"Name=hdnId", "Value=", "ENDITEM",
		"Name=hdnSales", "Value=350000", "ENDITEM",
		"Name=hdnImageName", "Value=sample05-10-2022_163724.jpg", "ENDITEM",
		"Name=hdnTBNew", "Value=1", "ENDITEM",
		"Name=hdnTBEdit", "Value=1", "ENDITEM",
		"Name=hdnTBDelete", "Value=1", "ENDITEM",
		"Name=hdnTBBusinessRule", "Value=1", "ENDITEM",
		"Name=hdnTBRefresh", "Value=1", "ENDITEM",
		"Name=hdnTBRefreshLocations", "Value=1", "ENDITEM",
		"Name=hdnMonitorType", "Value=0", "ENDITEM",
		"Name=hdnMonitorLevel", "Value=1", "ENDITEM",
		"Name=hdnStatus", "Value=0", "ENDITEM",
		"Name=hdfSelectedHierarchy", "Value=", "ENDITEM",
		"Name=hdnAttachedBR", "Value=", "ENDITEM",
		"Name=hdfSelectedIndexUnselectedBR", "Value=", "ENDITEM",
		"Name=hdfActivateBR", "Value=", "ENDITEM",
		"Name=hdfDeactivateBR", "Value=", "ENDITEM",
		"Name=hdfpucTargetsale", "Value=", "ENDITEM",
		"Name=hdfMonitorCriteriaExist", "Value=", "ENDITEM",
		"Name=hdfMonitorCriteriaExistOnRemoveAttachBR", "Value=", "ENDITEM",
		"Name=hdfIsMonitorCriteriadelete", "Value=", "ENDITEM",
		"Name=hdfSavePreviosStatus", "Value=", "ENDITEM",
		"Name=hdnPreviousId", "Value=", "ENDITEM",
		"Name=hdfExpanded", "Value=", "ENDITEM",
		"Name=hdfNodeEditingFlag", "Value=", "ENDITEM",
		"Name=hdfRemoved", "Value=", "ENDITEM",
		"Name=hdfDuplicateValue", "Value=", "ENDITEM",
		"Name=hdfHierarchySelectedNodeName", "Value=", "ENDITEM",
		"Name=hdfHierarchySelectedNodeText", "Value=", "ENDITEM",
		"Name=hdfDeleteByIdOnUncheck", "Value=", "ENDITEM",
		"Name=txtSearch", "Value=", "ENDITEM",
		"Name=cbptrlStrategy$trlStrategy", "Value={&quot;editorValues&quot;:&quot;&quot;,&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;7/taFsY5gtg3vt2AX9zl/CiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2/ZFhMlRsr/ucVR0alPJl5xmyDpj/f7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM+v20sSAvpYAJfs+VN9L+lgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs/XXfLgZJ/9ICUIcsYmKNTY/96g4zl/3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U+wqAaOf8/6SVc7II7Lk0lVSryJW5XwF9/cDQJ78XqtytNbFuMVNuKL+awWInU7k2FumE15rJRiS42kjANt0P1/6397anJ1qCIiT/LIltKuq33ivr/YQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0/7palXOofceNskD/UxS1i+IotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV+UxBjY5Ur8gj8R78UWMB8yEx9XN/uYRVZwxxb+shi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH/bS7zq+tUXn5IAgWCYRgS8Efw3f3/RbVuG2cVsUqorWOb1sWxSSA/rB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs/569KcB+PZImBxq3GWuQFe96d55O0pj0685s6GZ8FiE+aR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGR"
		"DpQri+QOX7WEXpc78vPL68A9wSl28pHxy+B5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz/e2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs/eUBL/vq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59&quot;,&quot;focusedKey&quot;:&quot;999-888-202-114-0-1-2-0&quot;,&quot;resizingState&quot;:&quot;&quot;,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=txtStrategyID", "Value=115", "ENDITEM",
		"Name=txtStrategyName", "Value=PTName{pName}", "ENDITEM",
		"Name=txtStrategyDescription", "Value=PTDesc{pName}", "ENDITEM",
		"Name=cmbStatus_VI", "Value=1", "ENDITEM",
		"Name=cmbStatus", "Value=Active", "ENDITEM",
		"Name=cmbStatus$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:168:1:501:96:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbStatus$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbStatus$DDD$L", "Value=1", "ENDITEM",
		"Name=cmbMonitorType_VI", "Value=1", "ENDITEM",
		"Name=cmbMonitorType", "Value=Campaign", "ENDITEM",
		"Name=cmbMonitorType$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:200:1:501:50:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbMonitorType$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbMonitorType$DDD$L", "Value=1", "ENDITEM",
		"Name=cmbMonitorLevel_VI", "Value=2", "ENDITEM",
		"Name=cmbMonitorLevel", "Value=Amount", "ENDITEM",
		"Name=cmbMonitorLevel$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:232:1:501:50:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbMonitorLevel$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbMonitorLevel$DDD$L", "Value=2", "ENDITEM",
		"Name=txtSales", "Value=350000", "ENDITEM",
		"Name=txtLocation", "Value=", "ENDITEM",
		"Name=ucStrategy", "Value={&quot;inputCount&quot;:1}", "ENDITEM",
		"Name=pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucMessageOnDeleteState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucShowBRState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucLocHierarchyState", "Value={&quot;windowsState&quot;:&quot;1:1:12000:307:61:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy", "Value={&quot;state&quot;:[{&quot;s&quot;:50,&quot;st&quot;:&quot;%&quot;,&quot;c&quot;:0,&quot;spt&quot;:0,&quot;spl&quot;:0},{&quot;s&quot;:50,&quot;st&quot;:&quot;%&quot;,&quot;c&quot;:0,&quot;spt&quot;:0,&quot;spl&quot;:0}]}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$txtSearchtrvHierarchy", "Value=", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$cbptrvHierarchy$trvHierarchy", "Value={&quot;nodesState&quot;:[{&quot;N0&quot;:&quot;&quot;},&quot;&quot;,{&quot;N0&quot;:&quot;U&quot;},{&quot;N0&quot;:&quot;LOC|1|N|&quot;}]}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$ctl07$grvLocationHierarchy", "Value={&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;i0j8lqCQQUF/QQlSS4D1mP/HBy5w3H4hajr1e4+1mo57Btu3YFdHAlpAz0ChXzI4IfEyPzfu2MXc2Z9oPrRkEc81z7Mt7+ClW9olONVIiFwJ7u7lyLpTW5ZTV1mwfC3xDkeW3RgvQlGHVXgGlmcjJw80Uqq7kJNBzOd0EpCRKpIJLV+SuVRpnpcVNOaKy67P73YEomtB9qq3YdNxfhJVoO1sKVGPLYTU2cGhGdUfa21s5z3G45nuSCc7jSdQCqe2tmylV9s+VIVKuwuKjdHNy1SBa8P67DmN2G0CYKQqwjG4ohqc/d/u1iJAkD9rHItjryAFMKArnTGLjdeNUwwG2m3ZC+x1GZBiXgXiJGqNVBpjx0Ipj7PlDzwWMq1hXelI5vBz6JOZnAj+Sg49iXcXZc1mmfRlBcRdWYMiDmvo8nyhLQ0HXL2yuCp92ir1yVBrIRdICwzeVCjy+dD0mdtY28wPNrPOSNKee7ecJCbmbOcnNRY2EFmz5+hTa4IC5x23j6i9O6P96I5VXe46forVxw==&quot;,&quot;groupLevelState&quot;:{},&quot;keys&quot;:[],&quot;focusedRow&quot;:-1,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$chbSelectAll", "Value=I", "ENDITEM",
		"Name=pucStrategyOperationsState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucTargetSalesState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucTargetSales$ASPxPanel6$txtpucTargetSales", "Value=", "ENDITEM",
		"Name=pucStartegyPrintState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucStartegyPrint$ASPxPanel8$grvStrategyPrint", "Value={&quot;focusedRow&quot;:-1,&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;n1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez/A5M+Ill/svc8VYzXj/DbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha+XrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY=&quot;,&quot;groupLevelState&quot;:{},&quot;keys&quot;:[],&quot;scrollState&quot;:null,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=pucMonitorCriteriaValidationState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_198,1_209,1_217,1_277,1_196,1_254,6_19,1_262,6_17,1_260,6_14,1_263,6_18,1_256,1_244,6_15,1_216,1_190,1_223,1_208,1_206,1_288,1_212,1_303,1_297,1_302,1_235,1_248,1_242,1_251,1_239,1_247,1_201,1_261,1_258,1_250,1_249", "ENDITEM",
		"Name=DXCss", "Value=1_40,1_50,1_51,1_4,1_16,1_17,1_14,1_13,6_1,6_3,6_0,1_22,1_21,Styles/Strategy.css,Styles/Common.css,Styles/Master.css,Styles/BusinessRule.css,Font/fonts.css,V6UI/font-awesome.min.css", "ENDITEM",
		"Name=__CALLBACKID", "Value=pucLocHierarchy", "ENDITEM",
		"Name=__CALLBACKPARAM", "Value=c0:-1;", "ENDITEM",
		"LAST");

	lr_think_time(5);

	web_custom_request("Strategy.aspx_6",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t70.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=New&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%"
		"26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0p"
		"j0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonito"
		"rType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A61%3A0%3A-1000"
		"0%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3"
		"B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B15yxVrBOV5Xrfgas8zO%2FfWTnG6ccJctaaQHEJlBF5cvIolHQoN%2Ffn7E9xE%2BffuQr1sYVrLY7bUV8PASyCVnLyQpjlWbf%2BMjAlRH8Fnv5xgn3OPc9MfCoXb8qwEHHmcjUiWy9ZtdJbLZJh67cdPEUSoEDNGgLkg%2F9DdBMHjj7Hta1D2tygGxgxQG%2Boi77J2gZaWbL9jxBlz7SJdhsbKuDamW94i2Ua44WvziJQs%2BY1rOgFOKAm1EnakbXK2kD8OC2Nb918b9nD8ubRt0DSKNuVt21J3ojuXKdUDCjD1fG82ZNsJdqG%2FWP9GwmadJkjnBELZBz%2BtSf%2BcFHnXfaR3eLm0QOdsoNo3w0xqOfJW6jaJhmxtR0l%2Bg4%2B9Y6Yr3T%2B04fo6MIPZjzC2IQnF6KSvjGvn6kS43lvXiEdfWNXFPFnDYAdnsLaG70ne%2FDnI4dHOJILhs7sYgUALBOVSdIx7AwweBZLePfQi2lL3xxj6HUp2bwC4tQI6qlTbFfkqluD6aqyWg4rFuQEYEg6WXQHQs8Y0h%2Fzh8DKXfTauMEShbAg0lGtOi1kjLtuiL%2BooV9AWvB%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-"
		"10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpD"
		"SBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesom"
		"e.min.css&__CALLBACKID=cbpSelectHierarchy&__CALLBACKPARAM=c0%3ALOC%7C1%7CN%7C%7C1",
		"LAST");

	web_custom_request("Strategy.aspx_7",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t71.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=New&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%"
		"26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0p"
		"j0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonito"
		"rType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A61%3A0%3A-1000"
		"0%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3"
		"B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B15yxVrBOV5Xrfgas8zO%2FfWTnG6ccJctaaQHEJlBF5cvIolHQoN%2Ffn7E9xE%2BffuQr1sYVrLY7bUV8PASyCVnLyQpjlWbf%2BMjAlRH8Fnv5xgn3OPc9MfCoXb8qwEHHmcjUiWy9ZtdJbLZJh67cdPEUSoEDNGgLkg%2F9DdBMHjj7Hta1D2tygGxgxQG%2Boi77J2gZaWbL9jxBlz7SJdhsbKuDamW94i2Ua44WvziJQs%2BY1rOgFOKAm1EnakbXK2kD8OC2Nb918b9nD8ubRt0DSKNuVt21J3ojuXKdUDCjD1fG82ZNsJdqG%2FWP9GwmadJkjnBELZBz%2BtSf%2BcFHnXfaR3eLm0QOdsoNo3w0xqOfJW6jaJhmxtR0l%2Bg4%2B9Y6Yr3T%2B04fo6MIPZjzC2IQnF6KSvjGvn6kS43lvXiEdfWNXFPFnDYAdnsLaG70ne%2FDnI4dHOJILhs7sYgUALBOVSdIx7AwweBZLePfQi2lL3xxj6HUp2bwC4tQI6qlTbFfkqluD6aqyWg4rFuQEYEg6WXQHQs8Y0h%2Fzh8DKXfTauMEShbAg0lGtOi1kjLtuiL%2BooV9AWvB%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-"
		"10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpD"
		"SBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesom"
		"e.min.css&__CALLBACKID=cbpSelectHierarchy&__CALLBACKPARAM=c1%3A%3BLOC%7C1%7CN%7C%7CAll%20Locations",
		"LAST");

	web_custom_request("Strategy.aspx_8",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t72.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=New&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%"
		"26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0p"
		"j0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonito"
		"rType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A61%3A0%3A-1000"
		"0%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3"
		"B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B15yxVrBOV5Xrfgas8zO%2FfWTnG6ccJctaaQHEJlBF5cvIolHQoN%2Ffn7E9xE%2BffuQr1sYVrLY7bUV8PASyCVnLyQpjlWbf%2BMjAlRH8Fnv5xgn3OPc9MfCoXb8qwEHHmcjUiWy9ZtdJbLZJh67cdPEUSoEDNGgLkg%2F9DdBMHjj7Hta1D2tygGxgxQG%2Boi77J2gZaWbL9jxBlz7SJdhsbKuDamW94i2Ua44WvziJQs%2BY1rOgFOKAm1EnakbXK2kD8OC2Nb918b9nD8ubRt0DSKNuVt21J3ojuXKdUDCjD1fG82ZNsJdqG%2FWP9GwmadJkjnBELZBz%2BtSf%2BcFHnXfaR3eLm0QOdsoNo3w0xqOfJW6jaJhmxtR0l%2Bg4%2B9Y6Yr3T%2B04fo6MIPZjzC2IQnF6KSvjGvn6kS43lvXiEdfWNXFPFnDYAdnsLaG70ne%2FDnI4dHOJILhs7sYgUALBOVSdIx7AwweBZLePfQi2lL3xxj6HUp2bwC4tQI6qlTbFfkqluD6aqyWg4rFuQEYEg6WXQHQs8Y0h%2Fzh8DKXfTauMEShbAg0lGtOi1kjLtuiL%2BooV9AWvB%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-"
		"10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpD"
		"SBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesom"
		"e.min.css&__CALLBACKID=pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy&__CALLBACKPARAM=c1%3AKV%7C2%3B%5B%5D%3BFR%7C2%3B-1%3BGB%7C13%3B10%7CCANCELEDIT%3B",
		"LAST");

	web_custom_request("Strategy.aspx_9",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t73.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=New&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%"
		"26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0p"
		"j0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonito"
		"rType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A61%3A0%3A-1000"
		"0%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3"
		"B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B15yxVrBOV5Xrfgas8zO%2FfWTnG6ccJctaaQHEJlBF5cvIolHQoN%2Ffn7E9xE%2BffuQr1sYVrLY7bUV8PASyCVnLyQpjlWbf%2BMjAlRH8Fnv5xgn3OPc9MfCoXb8qwEHHmcjUiWy9ZtdJbLZJh67cdPEUSoEDNGgLkg%2F9DdBMHjj7Hta1D2tygGxgxQG%2Boi77J2gZaWbL9jxBlz7SJdhsbKuDamW94i2Ua44WvziJQs%2BY1rOgFOKAm1EnakbXK2kD8OC2Nb918b9nD8ubRt0DSKNuVt21J3ojuXKdUDCjD1fG82ZNsJdqG%2FWP9GwmadJkjnBELZBz%2BtSf%2BcFHnXfaR3eLm0QOdsoNo3w0xqOfJW6jaJhmxtR0l%2Bg4%2B9Y6Yr3T%2B04fo6MIPZjzC2IQnF6KSvjGvn6kS43lvXiEdfWNXFPFnDYAdnsLaG70ne%2FDnI4dHOJILhs7sYgUALBOVSdIx7AwweBZLePfQi2lL3xxj6HUp2bwC4tQI6qlTbFfkqluD6aqyWg4rFuQEYEg6WXQHQs8Y0h%2Fzh8DKXfTauMEShbAg0lGtOi1kjLtuiL%2BooV9AWvB%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-"
		"10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpD"
		"SBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesom"
		"e.min.css&__CALLBACKID=pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy&__CALLBACKPARAM=c0%3AKV%7C2%3B%5B%5D%3BFR%7C2%3B-1%3BGB%7C13%3B10%7CCANCELEDIT%3B",
		"LAST");

	web_custom_request("Strategy.aspx_10",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t74.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=New&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%"
		"26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0p"
		"j0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonito"
		"rType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A307%3A61%3A0%3A-1000"
		"0%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3"
		"BT%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bd%2B%2BOahHcJN1QDxXZCsIdn7Vqm%2F%2Fj0KB43q4fTdvl%2F9%2F67PYKhfQGyRWqw8nyFDOZ%2BSX0aGDtYsQ6zYRe2opniN3TsCeswpC2zvX19Pb0I3C2Nf5KsFhj2DxEYcvyB4oOqBWasFAeGI%2FIyO9FNEGyBDJzMHyUpGg%2F4CFopZ0nzg1tjArkRx9YyegV5ODJl0qPO4CnGG0nJQQp9PxAPfrvX5bbqe50CL7MnrtgkIxCcNa%2BuXY4vZt9wDbJX%2FRnITkKoDrOB7bClB8WdXwJpKa%2BV1lgOqeWJaOowRVCFNyRULbzvRYJ4MjJpd6FOemaJzVT9Ob5U3i%2FG82IjMMEdFqMO5MIUAgXiIGVYOImHtaoCiOpjkAs3qWwDWrgsGkRP7uNoHix4a4UoqbIcp5x4X8uwVnit2YZuywnEYnFDrm8I11TLGr5sHbX7lXIW4%2BXUioaZ1uZSdkHzcOYaTWG7Ty705P7CtGO3uNg8I3UJf%2FO12Zo9eBt4bcO3VEd82XV7Hf%2BqXc3OZuZWxn9Ik0RKN9Uqdbaxkula5lbCUE0uYfACX%2BeiRgKZpe99V%2FRrKC%2Bn4hhPbKYwfen6YibQsJBAh5SmA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyO"
		"perationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuI"
		"sHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCo"
		"mmon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=cbpLocation&__CALLBACKPARAM=c0%3A",
		"LAST");

	 

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	lr_think_time(16);

	web_submit_data("Strategy.aspx_11",
		"Action=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx?DXUploadingCallback=ucStrategy",
		"Method=POST",
		"EncType=multipart/form-data",
		"RecContentType=text/html",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t75.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=__EVENTTARGET", "Value=", "ENDITEM",
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM",
		"Name=__VIEWSTATE", "Value={CorrelationParameter_2}", "ENDITEM",
		"Name=__VIEWSTATEGENERATOR", "Value=9ABF3D45", "ENDITEM",
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM",
		"Name=hdfClickedbutton", "Value=New", "ENDITEM",
		"Name=hdfMaxStrategyId", "Value=115", "ENDITEM",
		"Name=hdfCheckFromListBox", "Value=", "ENDITEM",
		"Name=hdfIsExists", "Value=", "ENDITEM",
		"Name=hdfStrategyId", "Value=999-888-202-114-0-1-2-0", "ENDITEM",
		"Name=hdftxtStrategyId", "Value=115", "ENDITEM",
		"Name=hdnerror", "Value=", "ENDITEM",
		"Name=hdnname", "Value=PTTest11", "ENDITEM",
		"Name=hdnDescription", "Value=PerfTest11", "ENDITEM",
		"Name=hdnId", "Value=", "ENDITEM",
		"Name=hdnSales", "Value=350000", "ENDITEM",
		"Name=hdnImageName", "Value=sample05-10-2022_163724.jpg", "ENDITEM",
		"Name=hdnTBNew", "Value=1", "ENDITEM",
		"Name=hdnTBEdit", "Value=1", "ENDITEM",
		"Name=hdnTBDelete", "Value=1", "ENDITEM",
		"Name=hdnTBBusinessRule", "Value=1", "ENDITEM",
		"Name=hdnTBRefresh", "Value=1", "ENDITEM",
		"Name=hdnTBRefreshLocations", "Value=1", "ENDITEM",
		"Name=hdnMonitorType", "Value=0", "ENDITEM",
		"Name=hdnMonitorLevel", "Value=1", "ENDITEM",
		"Name=hdnStatus", "Value=0", "ENDITEM",
		"Name=hdfSelectedHierarchy", "Value=;LOC|1|N||All Locations", "ENDITEM",
		"Name=hdnAttachedBR", "Value=", "ENDITEM",
		"Name=hdfSelectedIndexUnselectedBR", "Value=", "ENDITEM",
		"Name=hdfActivateBR", "Value=", "ENDITEM",
		"Name=hdfDeactivateBR", "Value=", "ENDITEM",
		"Name=hdfpucTargetsale", "Value=", "ENDITEM",
		"Name=hdfMonitorCriteriaExist", "Value=", "ENDITEM",
		"Name=hdfMonitorCriteriaExistOnRemoveAttachBR", "Value=", "ENDITEM",
		"Name=hdfIsMonitorCriteriadelete", "Value=", "ENDITEM",
		"Name=hdfSavePreviosStatus", "Value=", "ENDITEM",
		"Name=hdnPreviousId", "Value=", "ENDITEM",
		"Name=hdfExpanded", "Value=", "ENDITEM",
		"Name=hdfNodeEditingFlag", "Value=", "ENDITEM",
		"Name=hdfRemoved", "Value=", "ENDITEM",
		"Name=hdfDuplicateValue", "Value=", "ENDITEM",
		"Name=hdfHierarchySelectedNodeName", "Value=", "ENDITEM",
		"Name=hdfHierarchySelectedNodeText", "Value=", "ENDITEM",
		"Name=hdfDeleteByIdOnUncheck", "Value=", "ENDITEM",
		"Name=cbptrlStrategy$trlStrategy", "Value={&quot;editorValues&quot;:&quot;&quot;,&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;7/taFsY5gtg3vt2AX9zl/CiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2/ZFhMlRsr/ucVR0alPJl5xmyDpj/f7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM+v20sSAvpYAJfs+VN9L+lgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs/XXfLgZJ/9ICUIcsYmKNTY/96g4zl/3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U+wqAaOf8/6SVc7II7Lk0lVSryJW5XwF9/cDQJ78XqtytNbFuMVNuKL+awWInU7k2FumE15rJRiS42kjANt0P1/6397anJ1qCIiT/LIltKuq33ivr/YQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0/7palXOofceNskD/UxS1i+IotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV+UxBjY5Ur8gj8R78UWMB8yEx9XN/uYRVZwxxb+shi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH/bS7zq+tUXn5IAgWCYRgS8Efw3f3/RbVuG2cVsUqorWOb1sWxSSA/rB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs/569KcB+PZImBxq3GWuQFe96d55O0pj0685s6GZ8FiE+aR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGR"
		"DpQri+QOX7WEXpc78vPL68A9wSl28pHxy+B5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz/e2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs/eUBL/vq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59&quot;,&quot;focusedKey&quot;:&quot;999-888-202-114-0-1-2-0&quot;,&quot;resizingState&quot;:&quot;&quot;,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=txtStrategyName", "Value=PTName{pName}", "ENDITEM",
		"Name=txtStrategyDescription", "Value=PTDesc{pName}", "ENDITEM",
		"Name=cmbStatus_VI", "Value=1", "ENDITEM",
		"Name=cmbStatus", "Value=Active", "ENDITEM",
		"Name=cmbStatus$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:168:1:501:96:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbStatus$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbStatus$DDD$L", "Value=1", "ENDITEM",
		"Name=cmbMonitorType_VI", "Value=1", "ENDITEM",
		"Name=cmbMonitorType", "Value=Campaign", "ENDITEM",
		"Name=cmbMonitorType$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:200:1:501:50:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbMonitorType$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbMonitorType$DDD$L", "Value=1", "ENDITEM",
		"Name=cmbMonitorLevel_VI", "Value=2", "ENDITEM",
		"Name=cmbMonitorLevel", "Value=Amount", "ENDITEM",
		"Name=cmbMonitorLevel$DDDState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:784:232:1:501:50:1:0:0:0&quot;}", "ENDITEM",
		"Name=cmbMonitorLevel$DDD$L$State", "Value={&quot;CustomCallback&quot;:&quot;&quot;}", "ENDITEM",
		"Name=cmbMonitorLevel$DDD$L", "Value=2", "ENDITEM",
		"Name=txtSales", "Value=350000", "ENDITEM",
		"Name=txtLocation", "Value=, LOC", "ENDITEM",
		"Name=ucStrategy", "Value={&quot;inputCount&quot;:1}", "ENDITEM",
		"Name=ucStrategy_TextBoxT_Input", "Value=", "File=yes", "ENDITEM",
		"Name=ucStrategy_TextBox0_Input", "Value=sample.jpg", "File=yes", "ENDITEM",
		"Name=pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucMessageOnDeleteState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucShowBRState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucLocHierarchyState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:307:61:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy", "Value={&quot;state&quot;:[{&quot;st&quot;:&quot;%&quot;,&quot;s&quot;:50,&quot;c&quot;:0,&quot;spt&quot;:0,&quot;spl&quot;:0},{&quot;st&quot;:&quot;%&quot;,&quot;s&quot;:50,&quot;c&quot;:0,&quot;spt&quot;:0,&quot;spl&quot;:0}]}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$txtSearchtrvHierarchy", "Value=", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$cbptrvHierarchy$trvHierarchy", "Value={&quot;nodesState&quot;:[{&quot;N0&quot;:&quot;&quot;},&quot;&quot;,{&quot;N0&quot;:&quot;C&quot;},{&quot;N0&quot;:&quot;LOC|1|N|&quot;}]}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$ctl07$grvLocationHierarchy", "Value={&quot;selection&quot;:&quot;T&quot;,&quot;callbackState&quot;:&quot;d++OahHcJN1QDxXZCsIdn7Vqm//j0KB43q4fTdvl/9/67PYKhfQGyRWqw8nyFDOZ+SX0aGDtYsQ6zYRe2opniN3TsCeswpC2zvX19Pb0I3C2Nf5KsFhj2DxEYcvyB4oOqBWasFAeGI/IyO9FNEGyBDJzMHyUpGg/4CFopZ0nzg1tjArkRx9YyegV5ODJl0qPO4CnGG0nJQQp9PxAPfrvX5bbqe50CL7MnrtgkIxCcNa+uXY4vZt9wDbJX/RnITkKoDrOB7bClB8WdXwJpKa+V1lgOqeWJaOowRVCFNyRULbzvRYJ4MjJpd6FOemaJzVT9Ob5U3i/G82IjMMEdFqMO5MIUAgXiIGVYOImHtaoCiOpjkAs3qWwDWrgsGkRP7uNoHix4a4UoqbIcp5x4X8uwVnit2YZuywnEYnFDrm8I11TLGr5sHbX7lXIW4+XUioaZ1uZSdkHzcOYaTWG7Ty705P7CtGO3uNg8I3UJf/O12Zo9eBt4bcO3VEd82XV7Hf+qXc3OZuZWxn9Ik0RKN9Uqdbaxkula5lbCUE0uYfACX+eiRgKZpe99V/RrKC+n4hhPbKYwfen6YibQsJBAh5SmA==&quot;,&quot;groupLevelState&quot;:{},&quot;keys&quot;:[&quot;LOC&quot;],&quot;focusedRow&quot;:0,&quot;toolbar&quot;:null,&quot;contextMenu&quot;:null}", "ENDITEM",
		"Name=pucLocHierarchy$ctl15$splStrategyLocationHierarchy$chbSelectAll", "Value=I", "ENDITEM",
		"Name=pucStrategyOperationsState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucTargetSalesState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucTargetSales$ASPxPanel6$txtpucTargetSales", "Value=", "ENDITEM",
		"Name=pucStartegyPrintState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=pucStartegyPrint$ASPxPanel8$grvStrategyPrint", "Value={&quot;focusedRow&quot;:-1,&quot;selection&quot;:&quot;&quot;,&quot;callbackState&quot;:&quot;n1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez/A5M+Ill/svc8VYzXj/DbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha+XrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY=&quot;,&quot;groupLevelState&quot;:{},&quot;keys&quot;:[],&quot;scrollState&quot;:null,&quot;toolbar&quot;:null}", "ENDITEM",
		"Name=pucMonitorCriteriaValidationState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_198,1_209,1_217,1_277,1_196,1_254,6_19,1_262,6_17,1_260,6_14,1_263,6_18,1_256,1_244,6_15,1_216,1_190,1_223,1_208,1_206,1_288,1_212,1_303,1_297,1_302,1_235,1_248,1_242,1_251,1_239,1_247,1_201,1_261,1_258,1_250,1_249", "ENDITEM",
		"Name=DXCss", "Value=1_40,1_50,1_51,1_4,1_16,1_17,1_14,1_13,6_1,6_3,6_0,1_22,1_21,Styles/Strategy.css,Styles/Common.css,Styles/Master.css,Styles/BusinessRule.css,Font/fonts.css,V6UI/font-awesome.min.css", "ENDITEM",
		"LAST");

	web_custom_request("Strategy.aspx_12",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t76.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=New&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%"
		"26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0p"
		"j0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonito"
		"rType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=%2C%20LOC&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A61%3A0%3"
		"A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%3B%3A%26"
		"quot%3BT%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bd%2B%2BOahHcJN1QDxXZCsIdn7Vqm%2F%2Fj0KB43q4fTdvl%2F9%2F67PYKhfQGyRWqw8nyFDOZ%2BSX0aGDtYsQ6zYRe2opniN3TsCeswpC2zvX19Pb0I3C2Nf5KsFhj2DxEYcvyB4oOqBWasFAeGI%2FIyO9FNEGyBDJzMHyUpGg%2F4CFopZ0nzg1tjArkRx9YyegV5ODJl0qPO4CnGG0nJQQp9PxAPfrvX5bbqe50CL7MnrtgkIxCcNa%2BuXY4vZt9wDbJX%2FRnITkKoDrOB7bClB8WdXwJpKa%2BV1lgOqeWJaOowRVCFNyRULbzvRYJ4MjJpd6FOemaJzVT9Ob5U3i%2FG82IjMMEdFqMO5MIUAgXiIGVYOImHtaoCiOpjkAs3qWwDWrgsGkRP7uNoHix4a4UoqbIcp5x4X8uwVnit2YZuywnEYnFDrm8I11TLGr5sHbX7lXIW4%2BXUioaZ1uZSdkHzcOYaTWG7Ty705P7CtGO3uNg8I3UJf%2FO12Zo9eBt4bcO3VEd82XV7Hf%2BqXc3OZuZWxn9Ik0RKN9Uqdbaxkula5lbCUE0uYfACX%2BeiRgKZpe99V%2FRrKC%2Bn4hhPbKYwfen6YibQsJBAh5SmA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStr"
		"ategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZI"
		"HsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyle"
		"s%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=cbpSave&__CALLBACKPARAM=c0%3A",
		"LAST");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("GetApplicationTextMultiligual", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx", 
		"Snapshot=t77.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={'TextId':'55018'}", 
		"LAST");

	web_custom_request("Strategy.aspx_13",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t78.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=New&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-114-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%"
		"26quot%3B%3A%26quot%3B0%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3B7%2FtaFsY5gtg3vt2AX9zl%2FCiDW6njip7YrOeY15CcxViJcVr3APjfimJVvXQNHC5Tw2%2FZFhMlRsr%2FucVR0alPJl5xmyDpj%2Ff7djNvnzaRgl4MK1qN9Cxs7RfMkWWaNULn5v5y89b7PYE0vqAR7TJesjBQAeV7oybo0KlBW1kqnza3OgWt5aRbHStsfXKjjgAXVOKrzIM%2Bv20sSAvpYAJfs%2BVN9L%2BlgAMRQbtVKrcLnetD3LyfublpJ9YY6ClPDEXZZ3wxJkwxuA9NAzs%2FXXfLgZJ%2F9ICUIcsYmKNTY%2F96g4zl%2F3mfdQd3m8TNsZJMXacqzyX5iUwqj3EmEeNE3QfgCgx41U%2BwqAaOf8%2F6SVc7II7Lk0lVSryJW5XwF9%2FcDQJ78XqtytNbFuMVNuKL%2BawWInU7k2FumE15rJRiS42kjANt0P1%2F6397anJ1qCIiT%2FLIltKuq33ivr%2FYQfXmxBOmBmsdxPbT2vkajGlfbb7UaIjEd7MKEDualAGSyHE97c9dnS0%2F7palXOofceNskD%2FUxS1i%2BIotSlbVkAN1QmWXvJwVdm0dMvY5xXdOy17Fm8NZqrrH62hzAfbHFHQ3YQFV%2BUxBjY5Ur8gj8R78UWMB8yEx9XN%2FuYRVZwxxb%2Bshi5KbcPo2oEO2lpVuRYEE0cdDB3xc7PG3vZS7bNu624v9iHngHCRIpYjH%2FbS7zq%2BtUXn5IAgWCYRgS8Efw3f3%2FRbVuG2cVsUqorWOb1sWxSSA%2FrB14PmGAb0FnWeXPKNNRVtmjM6jdL0BBtXe47sxn48u0Obfxs%2F569KcB%2BPZImBxq3GWuQFe96d55O0"
		"pj0685s6GZ8FiE%2BaR8A4skeHVOvd3jvwjkOsOwpYk36jQjx5G3fu1Zdd4RLA4kIGJhGgPWzfz3SHHAbqZI4DzlGRDpQri%2BQOX7WEXpc78vPL68A9wSl28pHxy%2BB5tEXk2aNJdjEWYuTA5CE5tCn8vjvNiqzv9acTT1G4Mzvdz%2Fe2Gd0kZmF30h6o3uE6odce9UTUWyRhRGs%2FeUBL%2Fvq1lnAAj1kPESM1UK6gnMbG1IEG0XjXh75WXlekNDWWrsTs7TqVVvP59%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-114-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonit"
		"orType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=%2C%20LOC&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A432%3A216%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A307%3A"
		"61%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26quot%3Bselection%26quot%"
		"3B%3A%26quot%3BT%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bd%2B%2BOahHcJN1QDxXZCsIdn7Vqm%2F%2Fj0KB43q4fTdvl%2F9%2F67PYKhfQGyRWqw8nyFDOZ%2BSX0aGDtYsQ6zYRe2opniN3TsCeswpC2zvX19Pb0I3C2Nf5KsFhj2DxEYcvyB4oOqBWasFAeGI%2FIyO9FNEGyBDJzMHyUpGg%2F4CFopZ0nzg1tjArkRx9YyegV5ODJl0qPO4CnGG0nJQQp9PxAPfrvX5bbqe50CL7MnrtgkIxCcNa%2BuXY4vZt9wDbJX%2FRnITkKoDrOB7bClB8WdXwJpKa%2BV1lgOqeWJaOowRVCFNyRULbzvRYJ4MjJpd6FOemaJzVT9Ob5U3i%2FG82IjMMEdFqMO5MIUAgXiIGVYOImHtaoCiOpjkAs3qWwDWrgsGkRP7uNoHix4a4UoqbIcp5x4X8uwVnit2YZuywnEYnFDrm8I11TLGr5sHbX7lXIW4%2BXUioaZ1uZSdkHzcOYaTWG7Ty705P7CtGO3uNg8I3UJf%2FO12Zo9eBt4bcO3VEd82XV7Hf%2BqXc3OZuZWxn9Ik0RKN9Uqdbaxkula5lbCUE0uYfACX%2BeiRgKZpe99V%2FRrKC%2Bn4hhPbKYwfen6YibQsJBAh5SmA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll="
		"I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9"
		"rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css"
		"%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=cbptrlStrategy%24trlStrategy&__CALLBACKPARAM=c0%3A11%20",
		"LAST");

	lr_end_transaction("Create new campaign",2);

	lr_think_time(14);

	lr_start_transaction("Edit campaign");

	web_custom_request("Strategy.aspx_14",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t79.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-115-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%26q"
		"uot%3B%3A%26quot%3B0%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B999_45_888_45_202_45_115_45_0_45_1_45_2_45_0%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BF%2FRpvJ%2B8fOO%2Fa7rfZfGPdaZ1tFQ2vtr5HN%2BKhH8dLZRpiK%2FNyBd87GQR6iB9FgOlHVy9IIuaMA8U4gDaYI4YQy994MC6sYBsj%2FkWKEJb%2FzTLTnavz89%2FMEsPuqMV%2FfFN78d4AXo5KCINzl0jDOUo5kvQARACT9mfo8dr2aZYmjC5MBOu0%2B6VVc7Mmf2XBBpnkNmZLiKsqY3drJ7ZPjYLe7zX4L2RTgJU3OrmJJPATioqY13X7Y%2FQhd6nGnCY6Uu71egXp5GvQkj6g2b0BmH5yx%2FthrmT56Ri1qJd8hBqEcPmGT1GzzVnzCbdcWN1Z3wvelx7afMbeyEHf4iBYKPG7fZi7FUIr%2B9U4HqRNejeKwGKX%2BEjK%2FZKZ4fQmcn331xHXhRUm44PTjEwIwSVdHp7qP8keFZfM8oL4nl8jQUt0UQvccB92KD%2FlIy26wTPef6CisCf2G%2FDzZdBGoiPoMAhdeq%2FSDXfpoDR0NHAqO4Q8O8t3sGNa1XzR9j8rNktYa8ugaD%2BFp0%2F3nRn%2FrK5f7ACtNtSxmoIowYZnAfYwcVwziKUnI1yeH3bOIjlhQyInli7G0noUs%2Fe2qAyBPjdOA5sUTTFRFYSwJOAGvnejOA1sBHEZ23BqbIqJK4lp1NUtEA%2B%2FjVxn1Yl39kBCakPp%2B2F8lrOCEYZXuwixX2CkOTjr5UDQil7crRL9qwGY1XGN4knUOohrLUtioGXYvmm5hyAqjcSesAeS%2B4zQsAspf566HvZWgVJ0y5pQkWoN8RYxjack9Q2sRKK1XVfmgYf2FxIklRs"
		"EG7Wvnw6yFn0XIgDnWglhd%2F40OA6guC6t78uqTUPEuuQOqxqu5WdzUJwDvv3A5tudYlx17u1a3QLPTPN%2FW2RLS05%2Bqwwfr8AelobtopjcsAC7QbHgqWsIug6LILM6Oryql1NVqhyUBcQ4QummHBNEFduAMxvyfOqYmwueY8KkUVWKJDcAKeHXUKaOrRD%2FVGHKHiqJ4XPp5QegeEVSYCcYL7v1hZ7l37PBpzHqfT6JhSBvMqUQTgdwPhPOHBJq2xetTWzUhqL7rAJZ1f9CxUDQ0xmbXCqlZ8HYidDpGfP%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-115-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyId={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A"
		"0%3A0%26quot%3B%7D&cmbMonitorType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=%2C%20LOC&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A216%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26qu"
		"ot%3B0%3A0%3A-1%3A307%3A61%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26"
		"quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bd%2B%2BOahHcJN1QDxXZCsIdn7Vqm%2F%2Fj0KB43q4fTdvl%2F9%2F67PYKhfQGyRWqw8nyFDOZ%2BSX0aGDtYsQ6zYRe2opniN3TsCeswpC2zvX19Pb0I3C2Nf5KsFhj2DxEYcvyB4oOqBWasFAeGI%2FIyO9FNEGyBDJzMHyUpGg%2F4CFopZ0nzg1tjArkRx9YyegV5ODJl0qPO4CnGG0nJQQp9PxAPfrvX5bbqe50CL7MnrtgkIxCcNa%2BuXY4vZt9wDbJX%2FRnITkKoDrOB7bClB8WdXwJpKa%2BV1lgOqeWJaOowRVCFNyRULbzvRYJ4MjJpd6FOemaJzVT9Ob5U3i%2FG82IjMMEdFqMO5MIUAgXiIGVYOImHtaoCiOpjkAs3qWwDWrgsGkRP7uNoHix4a4UoqbIcp5x4X8uwVnit2YZuywnEYnFDrm8I11TLGr5sHbX7lXIW4%2BXUioaZ1uZSdkHzcOYaTWG7Ty705P7CtGO3uNg8I3UJf%2FO12Zo9eBt4bcO3VEd82XV7Hf%2BqXc3OZuZWxn9Ik0RKN9Uqdbaxkula5lbCUE0uYfACX%2BeiRgKZpe99V%2FRrKC%2Bn4hhPbKYwfen6YibQsJBAh5SmA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationH"
		"ierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4"
		"vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21"
		"%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=cbpEditStrategyTab&__CALLBACKPARAM=c0%3A",
		"LAST");

	web_custom_request("Strategy.aspx_15",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t80.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-115-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues%26q"
		"uot%3B%3A%26quot%3B0%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B999_45_888_45_202_45_115_45_0_45_1_45_2_45_0%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BF%2FRpvJ%2B8fOO%2Fa7rfZfGPdaZ1tFQ2vtr5HN%2BKhH8dLZRpiK%2FNyBd87GQR6iB9FgOlHVy9IIuaMA8U4gDaYI4YQy994MC6sYBsj%2FkWKEJb%2FzTLTnavz89%2FMEsPuqMV%2FfFN78d4AXo5KCINzl0jDOUo5kvQARACT9mfo8dr2aZYmjC5MBOu0%2B6VVc7Mmf2XBBpnkNmZLiKsqY3drJ7ZPjYLe7zX4L2RTgJU3OrmJJPATioqY13X7Y%2FQhd6nGnCY6Uu71egXp5GvQkj6g2b0BmH5yx%2FthrmT56Ri1qJd8hBqEcPmGT1GzzVnzCbdcWN1Z3wvelx7afMbeyEHf4iBYKPG7fZi7FUIr%2B9U4HqRNejeKwGKX%2BEjK%2FZKZ4fQmcn331xHXhRUm44PTjEwIwSVdHp7qP8keFZfM8oL4nl8jQUt0UQvccB92KD%2FlIy26wTPef6CisCf2G%2FDzZdBGoiPoMAhdeq%2FSDXfpoDR0NHAqO4Q8O8t3sGNa1XzR9j8rNktYa8ugaD%2BFp0%2F3nRn%2FrK5f7ACtNtSxmoIowYZnAfYwcVwziKUnI1yeH3bOIjlhQyInli7G0noUs%2Fe2qAyBPjdOA5sUTTFRFYSwJOAGvnejOA1sBHEZ23BqbIqJK4lp1NUtEA%2B%2FjVxn1Yl39kBCakPp%2B2F8lrOCEYZXuwixX2CkOTjr5UDQil7crRL9qwGY1XGN4knUOohrLUtioGXYvmm5hyAqjcSesAeS%2B4zQsAspf566HvZWgVJ0y5pQkWoN8RYxjack9Q2sRKK1XVfmgYf2FxIklRs"
		"EG7Wvnw6yFn0XIgDnWglhd%2F40OA6guC6t78uqTUPEuuQOqxqu5WdzUJwDvv3A5tudYlx17u1a3QLPTPN%2FW2RLS05%2Bqwwfr8AelobtopjcsAC7QbHgqWsIug6LILM6Oryql1NVqhyUBcQ4QummHBNEFduAMxvyfOqYmwueY8KkUVWKJDcAKeHXUKaOrRD%2FVGHKHiqJ4XPp5QegeEVSYCcYL7v1hZ7l37PBpzHqfT6JhSBvMqUQTgdwPhPOHBJq2xetTWzUhqL7rAJZ1f9CxUDQ0xmbXCqlZ8HYidDpGfP%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-115-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyID={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1%3A0%3A"
		"0%3A0%26quot%3B%7D&cmbMonitorType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=%2C%20LOC&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A216%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%3A%26qu"
		"ot%3B0%3A0%3A-1%3A307%3A61%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy=%7B%26"
		"quot%3Bselection%26quot%3B%3A%26quot%3BT%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bd%2B%2BOahHcJN1QDxXZCsIdn7Vqm%2F%2Fj0KB43q4fTdvl%2F9%2F67PYKhfQGyRWqw8nyFDOZ%2BSX0aGDtYsQ6zYRe2opniN3TsCeswpC2zvX19Pb0I3C2Nf5KsFhj2DxEYcvyB4oOqBWasFAeGI%2FIyO9FNEGyBDJzMHyUpGg%2F4CFopZ0nzg1tjArkRx9YyegV5ODJl0qPO4CnGG0nJQQp9PxAPfrvX5bbqe50CL7MnrtgkIxCcNa%2BuXY4vZt9wDbJX%2FRnITkKoDrOB7bClB8WdXwJpKa%2BV1lgOqeWJaOowRVCFNyRULbzvRYJ4MjJpd6FOemaJzVT9Ob5U3i%2FG82IjMMEdFqMO5MIUAgXiIGVYOImHtaoCiOpjkAs3qWwDWrgsGkRP7uNoHix4a4UoqbIcp5x4X8uwVnit2YZuywnEYnFDrm8I11TLGr5sHbX7lXIW4%2BXUioaZ1uZSdkHzcOYaTWG7Ty705P7CtGO3uNg8I3UJf%2FO12Zo9eBt4bcO3VEd82XV7Hf%2BqXc3OZuZWxn9Ik0RKN9Uqdbaxkula5lbCUE0uYfACX%2BeiRgKZpe99V%2FRrKC%2Bn4hhPbKYwfen6YibQsJBAh5SmA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%26quot%3BLOC%26quot%3B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A0%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationH"
		"ierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4"
		"vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21"
		"%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesome.min.css&__CALLBACKID=pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy&__CALLBACKPARAM=c0%3ASR%7C1%3BT%3BKV%7C7%3B%5B%22LOC%22%5D%3BFR%7C1%3B0%3BGB%7C24%3B14%7CCUSTOMCALLBACK5%7CClear%3B",
		"LAST");

	 

	web_custom_request("Strategy.aspx_16",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t81.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=Edit&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-115-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues"
		"%26quot%3B%3A%26quot%3B0%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B999_45_888_45_202_45_115_45_0_45_1_45_2_45_0%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BF%2FRpvJ%2B8fOO%2Fa7rfZfGPdaZ1tFQ2vtr5HN%2BKhH8dLZRpiK%2FNyBd87GQR6iB9FgOlHVy9IIuaMA8U4gDaYI4YQy994MC6sYBsj%2FkWKEJb%2FzTLTnavz89%2FMEsPuqMV%2FfFN78d4AXo5KCINzl0jDOUo5kvQARACT9mfo8dr2aZYmjC5MBOu0%2B6VVc7Mmf2XBBpnkNmZLiKsqY3drJ7ZPjYLe7zX4L2RTgJU3OrmJJPATioqY13X7Y%2FQhd6nGnCY6Uu71egXp5GvQkj6g2b0BmH5yx%2FthrmT56Ri1qJd8hBqEcPmGT1GzzVnzCbdcWN1Z3wvelx7afMbeyEHf4iBYKPG7fZi7FUIr%2B9U4HqRNejeKwGKX%2BEjK%2FZKZ4fQmcn331xHXhRUm44PTjEwIwSVdHp7qP8keFZfM8oL4nl8jQUt0UQvccB92KD%2FlIy26wTPef6CisCf2G%2FDzZdBGoiPoMAhdeq%2FSDXfpoDR0NHAqO4Q8O8t3sGNa1XzR9j8rNktYa8ugaD%2BFp0%2F3nRn%2FrK5f7ACtNtSxmoIowYZnAfYwcVwziKUnI1yeH3bOIjlhQyInli7G0noUs%2Fe2qAyBPjdOA5sUTTFRFYSwJOAGvnejOA1sBHEZ23BqbIqJK4lp1NUtEA%2B%2FjVxn1Yl39kBCakPp%2B2F8lrOCEYZXuwixX2CkOTjr5UDQil7crRL9qwGY1XGN4knUOohrLUtioGXYvmm5hyAqjcSesAeS%2B4zQsAspf566HvZWgVJ0y5pQkWoN8RYxjack9Q2sRKK1XVfmgYf2FxI"
		"klRsEG7Wvnw6yFn0XIgDnWglhd%2F40OA6guC6t78uqTUPEuuQOqxqu5WdzUJwDvv3A5tudYlx17u1a3QLPTPN%2FW2RLS05%2Bqwwfr8AelobtopjcsAC7QbHgqWsIug6LILM6Oryql1NVqhyUBcQ4QummHBNEFduAMxvyfOqYmwueY8KkUVWKJDcAKeHXUKaOrRD%2FVGHKHiqJ4XPp5QegeEVSYCcYL7v1hZ7l37PBpzHqfT6JhSBvMqUQTgdwPhPOHBJq2xetTWzUhqL7rAJZ1f9CxUDQ0xmbXCqlZ8HYidDpGfP%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-115-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyID={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}New&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1"
		"%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=%2C%20LOC&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A432%3A216%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%3B%"
		"3A%26quot%3B0%3A0%3A-1%3A307%3A61%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierarchy"
		"=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BPTnOwUgjWq7gcAtzX5veOYmWqOHUdzDqUMQiuLfGCu1CrrLGM%2Fv%2Fxqa%2BYBRmTGiOzGCyDncrVeyGe76mFfjl%2BlJudq%2BojfDkwNLl%2BRs8TcG9E8OPoe3ZfliBhfgmlznmjTVtF%2Binu5LL2ME9viyksVvsuyXN0oI%2B7awd1e7%2BPALwqT0tplhQI%2BQEE8hwCzrlFUIHd%2B7tB5f%2B%2ByX9VfVoTuo6hqbpHVi7sJomaI%2Bjmu4tudZDRno8IEr3h3YCEndw7bwm0FBy8f6tr6rAQ3acd3P%2F%2FchUPuKrv77pyaR78ocmAZrM2mfeP8kLJSPCIN5JznfDL6UhD7JaaRF41bxLQBM%2FUT6G%2BXv192G%2BlHh8%2FH54t%2F4B1av%2F8XzndivNUtQqD7b3SWeBGJaNqzIez7Y5Hl1HVUMUYxG4w42WRkkmtQ7CSmi3utU2kg5Hbon3Ld%2FFSiAoFDo5o60TvyV3GciilA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-"
		"10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBnZpD"
		"SBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awesom"
		"e.min.css&__CALLBACKID=cbpSave&__CALLBACKPARAM=c0%3A",
		"LAST");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_custom_request("GetApplicationTextMultiligual_2", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx/GetApplicationTextMultiligual", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx", 
		"Snapshot=t82.inf", 
		"Mode=HTML", 
		"EncType=application/json; charset=UTF-8", 
		"Body={'TextId':'55018'}", 
		"LAST");

	web_custom_request("Strategy.aspx_17",
		"URL=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Method=POST",
		"Resource=0",
		"RecContentType=text/plain",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/Strategy.aspx",
		"Snapshot=t83.inf",
		"Mode=HTML",
		"EncType=application/x-www-form-urlencoded; charset=UTF-8",
		"Body=__EVENTTARGET=&__EVENTARGUMENT=&__VIEWSTATE={CorrelationParameter_2_URL2}&__VIEWSTATEGENERATOR=9ABF3D45&__VIEWSTATEENCRYPTED=&hdfClickedbutton=Edit&hdfMaxStrategyId={pCampaignID}&hdfCheckFromListBox=&hdfIsExists=&hdfStrategyId=999-888-202-115-0-1-2-0&hdftxtStrategyId={pCampaignID}&hdnerror=&hdnname=PTTest11&hdnDescription=PerfTest11&hdnId=&hdnSales=350000&hdnImageName=sample05-10-2022_163724.jpg&hdnTBNew=1&hdnTBEdit=1&hdnTBDelete=1&hdnTBBusinessRule=1&hdnTBRefresh=1&hdnTBRefreshLocations=1&hdnMonitorType=0&hdnMonitorLevel=1&hdnStatus=0&hdfSelectedHierarchy=%3BLOC%7C1%7CN%7C%7CAll%20Locations&hdnAttachedBR=&hdfSelectedIndexUnselectedBR=&hdfActivateBR=&hdfDeactivateBR=&hdfpucTargetsale=&hdfMonitorCriteriaExist=&hdfMonitorCriteriaExistOnRemoveAttachBR=&hdfIsMonitorCriteriadelete=&hdfSavePreviosStatus=&hdnPreviousId=&hdfExpanded=&hdfNodeEditingFlag=&hdfRemoved=&hdfDuplicateValue=&hdfHierarchySelectedNodeName=&hdfHierarchySelectedNodeText=&hdfDeleteByIdOnUncheck=&txtSearch=&cbptrlStrategy%24trlStrategy=%7B%26quot%3BeditorValues"
		"%26quot%3B%3A%26quot%3B0%26quot%3B%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B999_45_888_45_202_45_115_45_0_45_1_45_2_45_0%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BF%2FRpvJ%2B8fOO%2Fa7rfZfGPdaZ1tFQ2vtr5HN%2BKhH8dLZRpiK%2FNyBd87GQR6iB9FgOlHVy9IIuaMA8U4gDaYI4YQy994MC6sYBsj%2FkWKEJb%2FzTLTnavz89%2FMEsPuqMV%2FfFN78d4AXo5KCINzl0jDOUo5kvQARACT9mfo8dr2aZYmjC5MBOu0%2B6VVc7Mmf2XBBpnkNmZLiKsqY3drJ7ZPjYLe7zX4L2RTgJU3OrmJJPATioqY13X7Y%2FQhd6nGnCY6Uu71egXp5GvQkj6g2b0BmH5yx%2FthrmT56Ri1qJd8hBqEcPmGT1GzzVnzCbdcWN1Z3wvelx7afMbeyEHf4iBYKPG7fZi7FUIr%2B9U4HqRNejeKwGKX%2BEjK%2FZKZ4fQmcn331xHXhRUm44PTjEwIwSVdHp7qP8keFZfM8oL4nl8jQUt0UQvccB92KD%2FlIy26wTPef6CisCf2G%2FDzZdBGoiPoMAhdeq%2FSDXfpoDR0NHAqO4Q8O8t3sGNa1XzR9j8rNktYa8ugaD%2BFp0%2F3nRn%2FrK5f7ACtNtSxmoIowYZnAfYwcVwziKUnI1yeH3bOIjlhQyInli7G0noUs%2Fe2qAyBPjdOA5sUTTFRFYSwJOAGvnejOA1sBHEZ23BqbIqJK4lp1NUtEA%2B%2FjVxn1Yl39kBCakPp%2B2F8lrOCEYZXuwixX2CkOTjr5UDQil7crRL9qwGY1XGN4knUOohrLUtioGXYvmm5hyAqjcSesAeS%2B4zQsAspf566HvZWgVJ0y5pQkWoN8RYxjack9Q2sRKK1XVfmgYf2FxI"
		"klRsEG7Wvnw6yFn0XIgDnWglhd%2F40OA6guC6t78uqTUPEuuQOqxqu5WdzUJwDvv3A5tudYlx17u1a3QLPTPN%2FW2RLS05%2Bqwwfr8AelobtopjcsAC7QbHgqWsIug6LILM6Oryql1NVqhyUBcQ4QummHBNEFduAMxvyfOqYmwueY8KkUVWKJDcAKeHXUKaOrRD%2FVGHKHiqJ4XPp5QegeEVSYCcYL7v1hZ7l37PBpzHqfT6JhSBvMqUQTgdwPhPOHBJq2xetTWzUhqL7rAJZ1f9CxUDQ0xmbXCqlZ8HYidDpGfP%26quot%3B%2C%26quot%3BfocusedKey%26quot%3B%3A%26quot%3B999-888-202-115-0-1-2-0%26quot%3B%2C%26quot%3BresizingState%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&txtStrategyID={pCampaignID}&txtStrategyName=PTName{pName}&txtStrategyDescription=PTDesc{pName}New&cmbStatus_VI=1&cmbStatus=Active&cmbStatus%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A168%3A1%3A501%3A96%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbStatus%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbStatus%24DDD%24L=1&cmbMonitorType_VI=1&cmbMonitorType=Campaign&cmbMonitorType%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A200%3A1%3A501%3A50%3A1"
		"%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorType%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorType%24DDD%24L=1&cmbMonitorLevel_VI=2&cmbMonitorLevel=Amount&cmbMonitorLevel%24DDDState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A784%3A232%3A1%3A501%3A50%3A1%3A0%3A0%3A0%26quot%3B%7D&cmbMonitorLevel%24DDD%24L%24State=%7B%26quot%3BCustomCallback%26quot%3B%3A%26quot%3B%26quot%3B%7D&cmbMonitorLevel%24DDD%24L=2&txtSales=350000&txtLocation=%2C%20LOC&ucStrategy=%7B%26quot%3BinputCount%26quot%3B%3A1%7D&pucMessageState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B1%3A1%3A12000%3A432%3A216%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucMessageOnDeleteState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucShowBRState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchyState=%7B%26quot%3BwindowsState%26quot%"
		"3B%3A%26quot%3B0%3A0%3A-1%3A307%3A61%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy=%7B%26quot%3Bstate%26quot%3B%3A%5B%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%2C%7B%26quot%3Bst%26quot%3B%3A%26quot%3B%25%26quot%3B%2C%26quot%3Bs%26quot%3B%3A50%2C%26quot%3Bc%26quot%3B%3A0%2C%26quot%3Bspt%26quot%3B%3A0%2C%26quot%3Bspl%26quot%3B%3A0%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24txtSearchtrvHierarchy=&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24cbptrvHierarchy%24trvHierarchy=%7B%26quot%3BnodesState%26quot%3B%3A%5B%7B%26quot%3BN0%26quot%3B%3A%26quot%3B%26quot%3B%7D%2C%26quot%3B%26quot%3B%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BC%26quot%3B%7D%2C%7B%26quot%3BN0%26quot%3B%3A%26quot%3BLOC%7C1%7CN%7C%26quot%3B%7D%5D%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24ctl07%24grvLocationHierar"
		"chy=%7B%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3BPTnOwUgjWq7gcAtzX5veOYmWqOHUdzDqUMQiuLfGCu1CrrLGM%2Fv%2Fxqa%2BYBRmTGiOzGCyDncrVeyGe76mFfjl%2BlJudq%2BojfDkwNLl%2BRs8TcG9E8OPoe3ZfliBhfgmlznmjTVtF%2Binu5LL2ME9viyksVvsuyXN0oI%2B7awd1e7%2BPALwqT0tplhQI%2BQEE8hwCzrlFUIHd%2B7tB5f%2B%2ByX9VfVoTuo6hqbpHVi7sJomaI%2Bjmu4tudZDRno8IEr3h3YCEndw7bwm0FBy8f6tr6rAQ3acd3P%2F%2FchUPuKrv77pyaR78ocmAZrM2mfeP8kLJSPCIN5JznfDL6UhD7JaaRF41bxLQBM%2FUT6G%2BXv192G%2BlHh8%2FH54t%2F4B1av%2F8XzndivNUtQqD7b3SWeBGJaNqzIez7Y5Hl1HVUMUYxG4w42WRkkmtQ7CSmi3utU2kg5Hbon3Ld%2FFSiAoFDo5o60TvyV3GciilA%3D%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Btoolbar%26quot%3B%3Anull%2C%26quot%3BcontextMenu%26quot%3B%3Anull%7D&pucLocHierarchy%24ctl15%24splStrategyLocationHierarchy%24chbSelectAll=I&pucStrategyOperationsState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%"
		"3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSalesState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucTargetSales%24ASPxPanel6%24txtpucTargetSales=&pucStartegyPrintState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&pucStartegyPrint%24ASPxPanel8%24grvStrategyPrint=%7B%26quot%3BfocusedRow%26quot%3B%3A-1%2C%26quot%3Bselection%26quot%3B%3A%26quot%3B%26quot%3B%2C%26quot%3BcallbackState%26quot%3B%3A%26quot%3Bn1yid6qaGha4pyugviQgNNs24c8rmunZYzCbTBycbpImPiAPgEC1v0cNwkFYywFkzUbBUUMKMmvLz0XQc30NrG4XYcOhmtAzrrA5xXpVbbQLHkUUTRHBFOQRVm2pV8yy6KMKO9YN9x9pjW8JOKa9XmcJie7i1Em19NamBQCN6n5eDjr3rHjm56v30826Kq5be44m7IbxPwwDvc4a5pFgLywez%2FA5M%2BIll%2Fsvc8VYzXj%2FDbFoKIuuT8FlMACOJW8GxuFo5BxJquBjfITWnMalwKk23LzWJBLg9bXoxL5TtyKBqzgqi76NxV4DBR7zJFIhUdMB4vsdCNQG2VYti8tXfj8ITgKN9rSkVBRZIHsfcuIsHfha%2BXrIr5XIgf4J1ec6CA4XefB751FtuTN2Zxwg3qUAByh8u5AU5Kkhr63oojc5ZC4eWhTmJa91Myck232B6EqsuMBn"
		"ZpDSBlCUiemya8AjVT5dIbtcMnanZwWFgBGr8pZkP345Ir5CSU0hwBdLaPYF2rFWqUXyo2hnMMWT5hl8xIJLvvHEGjsbbasvQAY%3D%26quot%3B%2C%26quot%3BgroupLevelState%26quot%3B%3A%7B%7D%2C%26quot%3Bkeys%26quot%3B%3A%5B%5D%2C%26quot%3BscrollState%26quot%3B%3Anull%2C%26quot%3Btoolbar%26quot%3B%3Anull%7D&pucMonitorCriteriaValidationState=%7B%26quot%3BwindowsState%26quot%3B%3A%26quot%3B0%3A0%3A-1%3A0%3A0%3A0%3A-10000%3A-10000%3A1%3A0%3A0%3A0%26quot%3B%7D&DXScript=1_304%2C1_185%2C1_298%2C1_211%2C1_188%2C1_182%2C1_287%2C1_290%2C1_184%2C1_198%2C1_209%2C1_217%2C1_277%2C1_196%2C1_254%2C6_19%2C1_262%2C6_17%2C1_260%2C6_14%2C1_263%2C6_18%2C1_256%2C1_244%2C6_15%2C1_216%2C1_190%2C1_223%2C1_208%2C1_206%2C1_288%2C1_212%2C1_303%2C1_297%2C1_302%2C1_235%2C1_248%2C1_242%2C1_251%2C1_239%2C1_247%2C1_201%2C1_261%2C1_258%2C1_250%2C1_249&DXCss=1_40%2C1_50%2C1_51%2C1_4%2C1_16%2C1_17%2C1_14%2C1_13%2C6_1%2C6_3%2C6_0%2C1_22%2C1_21%2CStyles%2FStrategy.css%2CStyles%2FCommon.css%2CStyles%2FMaster.css%2CStyles%2FBusinessRule.css%2CFont%2Ffonts.css%2CV6UI%2Ffont-awe"
		"some.min.css&__CALLBACKID=cbptrlStrategy%24trlStrategy&__CALLBACKPARAM=c0%3A11%20",
		"LAST");

	lr_end_transaction("Edit campaign",2);

	lr_start_transaction("Logoff");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	lr_think_time(13);

	web_custom_request("LogOut.aspx", 
		"URL=http://172.24.1.129/ETPAcceleratorSP4/LogOut.aspx", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx", 
		"Snapshot=t84.inf", 
		"Mode=HTML", 
		"EncType=", 
		"LAST");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_submit_data("HomePage.aspx",
		"Action=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx",
		"Method=POST",
		"RecContentType=text/html",
		"Referer=http://172.24.1.129/ETPAcceleratorSP4/HomePage.aspx",
		"Snapshot=t85.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=ctl00_tsmMaster_HiddenField", "Value=", "ENDITEM",
		"Name=__EVENTTARGET", "Value=", "ENDITEM",
		"Name=__EVENTARGUMENT", "Value=", "ENDITEM",
		"Name=__VIEWSTATE", "Value={CorrelationParameter_1}", "ENDITEM",
		"Name=__VIEWSTATEGENERATOR", "Value=2C7D260F", "ENDITEM",
		"Name=__VIEWSTATEENCRYPTED", "Value=", "ENDITEM",
		"Name=ctl00$hdfPageNameForTab", "Value=", "ENDITEM",
		"Name=ctl00$hdnLogout", "Value=Are you sure you want to logout ?", "ENDITEM",
		"Name=ctl00$MainContent$pgcTabs", "Value={&quot;activeTabIndex&quot;:3}", "ENDITEM",
		"Name=ctl00$MainContent$pucMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=ctl00$MainContent$hdnBRClose", "Value=", "ENDITEM",
		"Name=ctl00$MainContent$pucConfirmCBMessageState", "Value={&quot;windowsState&quot;:&quot;0:0:-1:0:0:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=ctl00$pucConfirmMessageState", "Value={&quot;windowsState&quot;:&quot;1:1:12000:509:264:0:-10000:-10000:1:0:0:0&quot;}", "ENDITEM",
		"Name=ctl00$pucConfirmMessage$ASPxPanel4$btnConfirmYes", "Value=Yes", "ENDITEM",
		"Name=DXScript", "Value=1_304,1_185,1_298,1_211,1_188,1_182,1_287,1_290,1_184,1_296,1_299,1_288,1_209,1_216,1_198", "ENDITEM",
		"Name=DXCss", "Value=1_50,1_51,1_16,1_13,1_40,1_4,1_14,V6UI/font-awesome.min.css,https://fortawesome.github.io/Font-Awesome/assets/font-awesome/css/font-awesome.css,Styles/Master.css,Images/Icons/ETP_icon.ico,Styles/Common.css,SideMenu/css/demo.css?v=1.1,Font/fonts.css,V6UI/css/aaddbb1.min.css?v=1.1,V6UI/css/aaddbb.min.css?v=1.1,V6UI/css/_all-skins.min.css?v=1.1,V6UI/css/common.css?v=1.1,Styles/loadingPanel.css", "ENDITEM",
		"LAST");

	lr_end_transaction("Logoff",2);

	return 0;
}
# 5 "d:\\project\\etp\\etp scripts\\campaignnewedit\\\\combined_CampaignNewEdit.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 6 "d:\\project\\etp\\etp scripts\\campaignnewedit\\\\combined_CampaignNewEdit.c" 2

